"""Tiny pixel-art toolkit used by generate_assets.py (Pillow only).

Design rules enforced here: hard edges only (no anti-aliasing, blur or gradients), every material is a
small hand-chosen colour ramp, and silhouettes get a 1px dark outline like vanilla item sprites.
"""
from PIL import Image

def rgb(h):
    h = h.lstrip('#')
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255)

# ---- Palettes (dark to light) --------------------------------------------------------------------------
OUT   = rgb('#12141a')
STEEL = [rgb(c) for c in ('#1f242c', '#323a46', '#4d5767', '#7a8697', '#a9b5c5', '#d6dfea')]
SOUL  = [rgb(c) for c in ('#17524d', '#2a9a8f', '#58d8c8', '#a8f4ea')]
GOLD  = [rgb(c) for c in ('#6a4c1a', '#a67c2e', '#d9b04c', '#f6dc8a')]
WOOD  = [rgb(c) for c in ('#2e2014', '#4d3620', '#6f5030', '#8f6a40')]
BONE  = [rgb(c) for c in ('#5e584a', '#8f8772', '#c4bca4', '#e8e2cc')]
CLEAR = (0, 0, 0, 0)

def new(w, h):
    return Image.new('RGBA', (w, h), CLEAR)

def px(img, x, y, c):
    if 0 <= x < img.width and 0 <= y < img.height and c is not None:
        img.putpixel((x, y), c)

def rect(img, x0, y0, x1, y1, c):
    """Inclusive rectangle."""
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            px(img, x, y, c)

def line(img, x0, y0, x1, y1, c, thick=1):
    dx, dy = abs(x1 - x0), -abs(y1 - y0)
    sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
    err = dx + dy
    while True:
        for ox in range(thick):
            for oy in range(thick):
                px(img, x0 + ox, y0 + oy, c)
        if x0 == x1 and y0 == y1:
            break
        e2 = 2 * err
        if e2 >= dy:
            err += dy; x0 += sx
        if e2 <= dx:
            err += dx; y0 += sy

def poly(img, pts, c):
    """Scanline polygon fill (inclusive of edges)."""
    ys = [p[1] for p in pts]
    for y in range(min(ys), max(ys) + 1):
        xs = []
        n = len(pts)
        for i in range(n):
            (xa, ya), (xb, yb) = pts[i], pts[(i + 1) % n]
            if ya == yb:
                if ya == y:
                    xs += [xa, xb]
                continue
            if min(ya, yb) <= y <= max(ya, yb):
                xs.append(xa + (y - ya) * (xb - xa) / (yb - ya))
        if xs:
            for x in range(int(round(min(xs))), int(round(max(xs))) + 1):
                px(img, x, y, c)

def outline(img, c=OUT):
    """Adds a 1px outline around the opaque silhouette (4-neighbourhood)."""
    src = img.copy()
    for y in range(img.height):
        for x in range(img.width):
            if src.getpixel((x, y))[3] == 0:
                for nx, ny in ((x+1, y), (x-1, y), (x, y+1), (x, y-1)):
                    if 0 <= nx < img.width and 0 <= ny < img.height and src.getpixel((nx, ny))[3] > 0:
                        img.putpixel((x, y), c)
                        break
    return img

def upscale(img, k):
    return img.resize((img.width * k, img.height * k), Image.NEAREST)

# ---- Cube UV painting (for entity and armour sheets) -------------------------------------------------------
def cube_faces(u, v, w, h, d):
    """Rectangles (x, y, width, height) of each face of a Minecraft box texture at offset (u, v)."""
    return {
        'top':    (u + d,         v,     w, d),
        'bottom': (u + d + w,     v,     w, d),
        'right':  (u,             v + d, d, h),
        'front':  (u + d,         v + d, w, h),
        'left':   (u + d + w,     v + d, d, h),
        'back':   (u + 2 * d + w, v + d, w, h),
    }

def paint_cube(img, u, v, w, h, d, painter):
    """painter(face, x, y, fw, fh) -> colour or None, x/y local to the face (0,0 = top-left)."""
    for face, (fx, fy, fw, fh) in cube_faces(u, v, w, h, d).items():
        for y in range(fh):
            for x in range(fw):
                c = painter(face, x, y, fw, fh)
                if c is not None:
                    px(img, fx + x, fy + y, c)
