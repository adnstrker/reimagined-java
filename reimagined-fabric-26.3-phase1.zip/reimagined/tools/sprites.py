"""Item sprites for Reimagined. Each function returns a finished RGBA image with outline."""
from pixel import *

def disc(img, cx, cy, r, c):
    for y in range(img.height):
        for x in range(img.width):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                px(img, x, y, c)

def ingot():
    im = new(16, 16)
    poly(im, [(6, 4), (13, 4), (10, 7), (3, 7)], STEEL[4])
    line(im, 6, 4, 13, 4, STEEL[5])
    rect(im, 3, 8, 10, 11, STEEL[2])
    rect(im, 3, 8, 10, 8, STEEL[3])
    rect(im, 3, 11, 10, 11, STEEL[1])
    poly(im, [(11, 8), (14, 5), (14, 8), (11, 11)], STEEL[1])
    for x, y in ((4, 10), (5, 10), (6, 9), (7, 9), (8, 10), (9, 10)):
        px(im, x, y, SOUL[2])
    return outline(im)

def crown():
    im = new(16, 16)
    for cx, top in ((3, 5), (13, 5), (8, 2)):
        poly(im, [(cx - 2, 10), (cx, top), (cx + 2, 10)], GOLD[2])
        line(im, cx, top, cx - 2, 10, GOLD[3])
    for cx, top in ((5, 7), (11, 7)):
        poly(im, [(cx - 1, 10), (cx, top), (cx + 1, 10)], GOLD[2])
    rect(im, 2, 10, 13, 13, GOLD[2])
    rect(im, 2, 10, 13, 10, GOLD[3])
    rect(im, 2, 13, 13, 13, GOLD[1])
    for x in (4, 8, 11):
        px(im, x, 11, SOUL[2]); px(im, x, 12, SOUL[1])
    px(im, 8, 3, SOUL[3]); px(im, 3, 6, SOUL[2]); px(im, 13, 6, SOUL[2])
    return outline(im)

def sigil():
    im = new(16, 16)
    poly(im, [(8, 1), (14, 8), (8, 14), (2, 8)], STEEL[2])
    poly(im, [(8, 3), (12, 8), (8, 12), (4, 8)], STEEL[0])
    line(im, 8, 1, 14, 8, STEEL[4]); line(im, 8, 1, 2, 8, STEEL[4])
    line(im, 14, 8, 8, 14, STEEL[1]); line(im, 2, 8, 8, 14, STEEL[1])
    line(im, 8, 5, 8, 11, SOUL[2]); line(im, 6, 8, 10, 8, SOUL[2])
    px(im, 8, 8, SOUL[3]); px(im, 8, 5, SOUL[3]); px(im, 8, 11, SOUL[1])
    return outline(im)

def sword():
    im = new(16, 16)
    line(im, 5, 9, 12, 2, STEEL[5])
    line(im, 6, 9, 13, 2, STEEL[3])
    px(im, 13, 2, STEEL[4]); px(im, 12, 1, STEEL[5])
    for x, y in ((8, 7), (10, 5)):
        px(im, x, y, SOUL[1])
    line(im, 3, 7, 7, 11, GOLD[2])
    line(im, 3, 8, 7, 12, GOLD[1])
    line(im, 4, 11, 2, 13, WOOD[2])
    line(im, 5, 11, 3, 13, WOOD[1])
    px(im, 1, 14, GOLD[2]); px(im, 2, 14, GOLD[1]); px(im, 1, 13, GOLD[3])
    return outline(im)

def axe():
    im = new(16, 16)
    line(im, 2, 14, 10, 6, WOOD[2])
    line(im, 3, 14, 11, 6, WOOD[1])
    poly(im, [(7, 4), (11, 1), (14, 1), (14, 10), (12, 9), (10, 7)], STEEL[3])
    for x, y in ((14, 4), (14, 5), (13, 5), (13, 6), (14, 6)):      # concave cutting edge
        px(im, x, y, CLEAR)
    line(im, 11, 1, 14, 1, STEEL[5]); line(im, 14, 1, 14, 3, STEEL[5]); line(im, 14, 7, 14, 10, STEEL[4])
    line(im, 7, 4, 10, 7, STEEL[1]); line(im, 10, 7, 12, 9, STEEL[1])
    px(im, 10, 3, SOUL[2]); px(im, 11, 4, SOUL[2]); px(im, 11, 3, SOUL[1])
    for x, y in ((5, 11), (6, 10)):
        px(im, x, y, GOLD[2])
    px(im, 3, 13, GOLD[1])
    return outline(im)

def spear(s=1):
    im = new(16 * s, 16 * s)
    S = lambda v: v * s
    line(im, S(1), S(14), S(9), S(6), WOOD[2], s)
    line(im, S(1) + s, S(14), S(9) + s, S(6), WOOD[1], s)
    line(im, S(9), S(5), S(13), S(1), STEEL[5], s)
    line(im, S(10), S(5), S(14), S(1), STEEL[3], s)
    line(im, S(11), S(5), S(14), S(2), STEEL[2], s)
    line(im, S(9), S(7), S(10), S(6), GOLD[2], s)
    line(im, S(7), S(8), S(8), S(7), SOUL[2], s)
    line(im, S(4), S(11), S(5), S(10), SOUL[1], s)
    return outline(im)

def staff():
    im = new(16, 16)
    line(im, 2, 14, 9, 7, WOOD[2])
    line(im, 3, 14, 10, 7, WOOD[1])
    for x, y in ((4, 12), (7, 9)):
        px(im, x, y, GOLD[2]); px(im, x + 1, y, GOLD[1])
    poly(im, [(9, 6), (13, 6), (12, 8), (10, 8)], STEEL[3])
    line(im, 9, 6, 13, 6, STEEL[5])
    disc(im, 11, 3, 2.6, SOUL[0])
    disc(im, 11, 3, 1.9, SOUL[1])
    disc(im, 11, 3, 1.1, SOUL[2])
    px(im, 11, 3, SOUL[3])
    return outline(im)

def helmet():
    im = new(16, 16)
    poly(im, [(5, 2), (10, 2), (12, 4), (12, 11), (3, 11), (3, 4)], STEEL[3])
    rect(im, 5, 8, 10, 11, CLEAR)          # open face
    rect(im, 3, 4, 12, 4, STEEL[5])        # highlight
    rect(im, 3, 6, 12, 7, GOLD[2]); rect(im, 3, 7, 12, 7, GOLD[1])
    rect(im, 3, 8, 4, 11, STEEL[2]); rect(im, 11, 8, 12, 11, STEEL[1])
    rect(im, 7, 8, 8, 10, STEEL[2])        # nose guard
    rect(im, 7, 1, 8, 3, SOUL[2]); px(im, 7, 1, SOUL[3])
    px(im, 6, 6, SOUL[2]); px(im, 9, 6, SOUL[2])
    return outline(im)

def chestplate():
    im = new(16, 16)
    poly(im, [(1, 3), (5, 3), (5, 8), (1, 8)], STEEL[3])
    poly(im, [(10, 3), (14, 3), (14, 8), (10, 8)], STEEL[3])
    rect(im, 1, 7, 5, 8, GOLD[2]); rect(im, 10, 7, 14, 8, GOLD[2])
    rect(im, 3, 4, 12, 14, STEEL[3])
    rect(im, 6, 3, 9, 4, CLEAR)            # neck
    rect(im, 3, 4, 12, 4, STEEL[5])
    rect(im, 3, 9, 4, 14, STEEL[2]); rect(im, 11, 9, 12, 14, STEEL[1])
    rect(im, 3, 12, 12, 13, GOLD[2]); rect(im, 3, 13, 12, 13, GOLD[1])
    line(im, 7, 6, 7, 11, SOUL[2]); line(im, 8, 6, 8, 11, SOUL[1])
    px(im, 7, 5, SOUL[3]); px(im, 7, 12, SOUL[3])
    rect(im, 3, 14, 12, 14, STEEL[1])
    return outline(im)

def leggings():
    im = new(16, 16)
    rect(im, 3, 2, 12, 5, STEEL[3]); rect(im, 3, 2, 12, 2, STEEL[5])
    rect(im, 3, 4, 12, 4, GOLD[2]); rect(im, 3, 5, 12, 5, GOLD[1])
    rect(im, 3, 6, 6, 14, STEEL[3]); rect(im, 9, 6, 12, 14, STEEL[3])
    rect(im, 3, 6, 3, 14, STEEL[4]); rect(im, 9, 6, 9, 14, STEEL[4])
    rect(im, 6, 6, 6, 14, STEEL[1]); rect(im, 12, 6, 12, 14, STEEL[1])
    rect(im, 3, 9, 6, 10, GOLD[2]); rect(im, 9, 9, 12, 10, GOLD[2])
    rect(im, 3, 10, 6, 10, GOLD[1]); rect(im, 9, 10, 12, 10, GOLD[1])
    px(im, 7, 3, SOUL[2]); px(im, 8, 3, SOUL[2])
    px(im, 4, 12, SOUL[2]); px(im, 10, 12, SOUL[2])
    rect(im, 3, 14, 6, 14, STEEL[1]); rect(im, 9, 14, 12, 14, STEEL[1])
    return outline(im)

def boots():
    im = new(16, 16)
    for x0 in (2, 9):
        rect(im, x0, 5, x0 + 4, 11, STEEL[3])
        rect(im, x0, 5, x0, 11, STEEL[4]); rect(im, x0 + 4, 5, x0 + 4, 11, STEEL[1])
        rect(im, x0, 5, x0 + 4, 6, GOLD[2]); rect(im, x0, 6, x0 + 4, 6, GOLD[1])
        rect(im, x0 - 1, 12, x0 + 5, 13, STEEL[2]); rect(im, x0 - 1, 13, x0 + 5, 13, STEEL[0])
        px(im, x0 + 2, 8, SOUL[2]); px(im, x0 + 2, 9, SOUL[1])
    return outline(im)

ITEMS = {
    'gravesteel_ingot': ingot, 'hollow_crown': crown, 'regent_sigil': sigil,
    'gravesteel_sword': sword, 'gravecleaver': axe, 'gravesteel_spear': spear, 'soulfire_staff': staff,
    'gravesteel_helmet': helmet, 'gravesteel_chestplate': chestplate,
    'gravesteel_leggings': leggings, 'gravesteel_boots': boots,
}
