#!/usr/bin/env python3
"""Generates every texture and data/resource JSON file of the Reimagined mod.

Run from the project root:  python3 tools/generate_assets.py
Requires Pillow. The output is committed, so building the mod does not need Python.
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from pixel import *
import sprites

ROOT = os.path.join(os.path.dirname(__file__), '..', 'src', 'main', 'resources')
ASSETS = os.path.join(ROOT, 'assets', 'reimagined')
DATA = os.path.join(ROOT, 'data', 'reimagined')
MC_DATA = os.path.join(ROOT, 'data', 'minecraft')

def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
        f.write('\n')

def save_png(img, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)

# ======================================================================================================
# Item textures, models and item definitions
# ======================================================================================================
def item_files():
    for name, fn in sprites.ITEMS.items():
        save_png(fn(), f'{ASSETS}/textures/item/{name}.png')
        write_json(f'{ASSETS}/models/item/{name}.json', {
            'parent': 'minecraft:item/handheld' if name in HANDHELD else 'minecraft:item/generated',
            'textures': {'layer0': f'reimagined:item/{name}'}})
        if name == 'gravesteel_spear':
            continue
        write_json(f'{ASSETS}/items/{name}.json', {'model': {'type': 'minecraft:model', 'model': f'reimagined:item/{name}'}})

    # The spear is drawn differently in hand (long 3D model) than in inventories (flat sprite).
    save_png(sprites.spear(2), f'{ASSETS}/textures/item/gravesteel_spear_in_hand.png')
    write_json(f'{ASSETS}/models/item/gravesteel_spear_in_hand.json', {
        'parent': 'minecraft:item/spear_in_hand', 'textures': {'layer0': 'reimagined:item/gravesteel_spear_in_hand'}})
    write_json(f'{ASSETS}/models/item/gravesteel_spear.json', {
        'parent': 'minecraft:item/generated', 'textures': {'layer0': 'reimagined:item/gravesteel_spear'}})
    write_json(f'{ASSETS}/items/gravesteel_spear.json', {'model': {
        'type': 'minecraft:select', 'property': 'minecraft:display_context',
        'cases': [{'when': ['gui', 'ground', 'fixed', 'on_shelf'], 'model': {'type': 'minecraft:model', 'model': 'reimagined:item/gravesteel_spear'}}],
        'fallback': {'type': 'minecraft:model', 'model': 'reimagined:item/gravesteel_spear_in_hand'}}})

HANDHELD = {'gravesteel_sword', 'gravecleaver', 'soulfire_staff'}

# ======================================================================================================
# Armour layers (64x32): head 0,0 / body 16,16 / arm 40,16 / leg 0,16, classic layout
# ======================================================================================================
def armor_layers():
    def plate(face, x, y, fw, fh, rim=1):
        """Base plating: steel with a lighter top edge and darker bottom edge."""
        shade = 3
        if face == 'top': shade = 4
        elif face == 'bottom': shade = 1
        elif face in ('right', 'back'): shade = 2
        if y == 0 and face not in ('top', 'bottom'): shade += 1
        if y == fh - 1 and face not in ('top', 'bottom'): shade -= 1
        return STEEL[max(0, min(5, shade))]

    # ---- layer 1: helmet, chestplate (+sleeves), boots ----
    L1 = new(64, 32)
    def head(face, x, y, fw, fh):
        if face == 'bottom':
            return None
        if face == 'front':
            if y <= 2: return GOLD[2] if y == 1 else (GOLD[3] if y == 0 else GOLD[1])
            if x in (0, fw - 1) and y <= 6: return STEEL[2]
            if x in (3, 4) and y <= 5: return STEEL[3]
            if x == 3 and y == 3: return SOUL[2]
            return None
        if y >= 6 and face in ('right', 'left') and x in (1, 2, 3): return None   # open ear area
        if face == 'back' and y >= 6: return STEEL[1]
        if y == 3 and face != 'top': return GOLD[2]
        return plate(face, x, y, fw, fh)
    paint_cube(L1, 0, 0, 8, 8, 8, head)
    # crest line on top
    for y in range(0, 8):
        px(L1, 8 + 3, y, SOUL[2]); px(L1, 8 + 4, y, SOUL[1])

    def body(face, x, y, fw, fh):
        c = plate(face, x, y, fw, fh)
        if face == 'front':
            if x in (3, 4) and 2 <= y <= 8: return SOUL[2] if x == 3 else SOUL[1]
            if y in (9, 10): return GOLD[2] if y == 9 else GOLD[1]
            if x in (0, fw - 1): return STEEL[2]
        if face == 'back' and x in (3, 4): return STEEL[1]
        return c
    paint_cube(L1, 16, 16, 8, 12, 4, body)

    def sleeve(face, x, y, fw, fh):
        if y >= 9 and face not in ('top',): return None
        if y == 4 or y == 5: return GOLD[2] if y == 4 else GOLD[1]
        if y < 4: return STEEL[4] if face == 'top' else STEEL[3 if face in ('front', 'left') else 2]
        return plate(face, x, y, fw, fh)
    paint_cube(L1, 40, 16, 4, 12, 4, sleeve)

    def boot(face, x, y, fw, fh):
        if y < 8 or face == 'top': return None
        if y == 8: return GOLD[2]
        if face == 'front' and x in (1, 2) and y == 9: return SOUL[2]
        if y == fh - 1: return STEEL[0]
        return plate(face, x, y, fw, fh)
    paint_cube(L1, 0, 16, 4, 12, 4, boot)
    save_png(L1, f'{ASSETS}/textures/entity/equipment/humanoid/gravesteel.png')
    save_png(L1, f'{ASSETS}/textures/entity/equipment/humanoid_baby/gravesteel.png')

    # ---- layer 2: leggings (belt on the body, thigh plates on the legs) ----
    L2 = new(64, 32)
    def belt(face, x, y, fw, fh):
        if face in ('top',): return None
        if y < 8: return None
        if y == 8: return GOLD[2]
        if y == 9 and face == 'front' and x in (3, 4): return SOUL[2]
        return plate(face, x, y, fw, fh)
    paint_cube(L2, 16, 16, 8, 12, 4, belt)
    def thigh(face, x, y, fw, fh):
        if y >= 10 or face == 'bottom': return None
        if y in (6, 7): return GOLD[2] if y == 6 else GOLD[1]
        if face == 'front' and x in (1, 2) and y == 3: return SOUL[2]
        return plate(face, x, y, fw, fh)
    paint_cube(L2, 0, 16, 4, 12, 4, thigh)
    save_png(L2, f'{ASSETS}/textures/entity/equipment/humanoid_leggings/gravesteel.png')
    save_png(L2, f'{ASSETS}/textures/entity/equipment/humanoid_leggings_baby/gravesteel.png')

    layer = lambda: {'texture': 'reimagined:gravesteel'}
    write_json(f'{ASSETS}/equipment/gravesteel.json', {'layers': {
        'humanoid': [layer()], 'humanoid_baby': [layer()],
        'humanoid_leggings': [layer()], 'humanoid_leggings_baby': [layer()]}})

# ======================================================================================================
# Hollow Regent entity texture (128x64) - layout must match HollowRegentModel.createBodyLayer()
# ======================================================================================================
def regent_texture():
    T = new(128, 64)
    def shade_of(face):
        return {'top': 1, 'front': 0, 'left': -1, 'right': -1, 'back': -1, 'bottom': -2}[face]
    def ramp(r, i, face):
        return r[max(0, min(len(r) - 1, i + shade_of(face)))]

    # Skull (10x10x10): bone with dark sockets, cyan glow, teeth, a couple of fixed cracks.
    def skull(face, x, y, fw, fh):
        if face == 'front':
            if y in (4, 5) and x in (2, 3, 6, 7):
                return SOUL[3] if (y == 4 and x in (3, 6)) else STEEL[0]
            if y in (6, 7) and x in (4, 5): return STEEL[0]
            if y == 8: return BONE[1] if x % 2 == 0 else STEEL[0]
            if y == 9: return BONE[0] if x % 2 == 0 else STEEL[0]
            if y == 3 and x in (4, 5): return BONE[1]
            return BONE[2] if y < 3 else BONE[2 if (x in (0, 9)) is False else 1]
        if face == 'top':
            return BONE[3] if (x + y) % 5 else BONE[2]
        if (face, x, y) in {('back', 2, 3), ('back', 3, 4), ('back', 3, 5), ('left', 4, 2), ('left', 5, 3)}:
            return BONE[0]
        return ramp(BONE, 2, face)
    paint_cube(T, 0, 0, 10, 10, 10, skull)

    # Crown band (11x2x11), spikes (2x5x2 and 2x7x2)
    paint_cube(T, 0, 46, 11, 2, 11, lambda f, x, y, w, h: (SOUL[2] if (f == 'front' and x in (2, 5, 8) and y == 0) else ramp(GOLD, 2 if y == 0 else 1, f)))
    paint_cube(T, 104, 0, 2, 5, 2, lambda f, x, y, w, h: SOUL[3] if (f == 'top') else ramp(GOLD, 3 if y < 1 else 2, f))
    paint_cube(T, 112, 0, 2, 7, 2, lambda f, x, y, w, h: SOUL[3] if (f == 'top') else ramp(GOLD, 3 if y < 1 else 2, f))

    # Torso (16x18x8): dark steel breastplate over exposed ribs, gold collar and belt, cyan rune core.
    def torso(face, x, y, fw, fh):
        base = ramp(STEEL, 1, face)
        if face == 'front':
            if y < 2: return ramp(GOLD, 2 if y == 0 else 1, face)
            if y in (5, 7, 9, 11) and 2 <= x <= 13: return BONE[1] if y != 11 else BONE[0]
            if y in (6, 8, 10) and 2 <= x <= 13: return STEEL[0]
            if x in (7, 8) and 3 <= y <= 12: return SOUL[2] if x == 7 else SOUL[1]
            if y in (14, 15): return ramp(GOLD, 2 if y == 14 else 1, face)
            if x in (0, 15) or y == 2: return STEEL[2]
            if y >= 16: return STEEL[0]
            return base
        if face == 'back':
            if x in (7, 8) and 2 <= y <= 14: return BONE[2 if x == 7 else 1]
            if y in (14, 15): return ramp(GOLD, 1, face)
            return base
        if face in ('top', 'bottom'):
            return ramp(GOLD, 1, face) if face == 'top' else STEEL[0]
        if y in (14, 15): return ramp(GOLD, 1, face)
        return ramp(STEEL, 1 + (1 if (x + y) % 6 == 0 else 0), face)
    paint_cube(T, 0, 20, 16, 18, 8, torso)

    # Arms (6x22x6): pauldron, bone upper arm, steel bracer with cyan line, bony hand.
    def arm(face, x, y, fw, fh):
        if face in ('top',): return STEEL[3]
        if face == 'bottom': return BONE[0]
        if y < 5: return ramp(STEEL, 2 + (1 if y == 0 else 0), face)
        if y == 5: return ramp(GOLD, 2, face)
        if y < 14: return ramp(BONE, 1 + (1 if x % 3 == 1 else 0), face)
        if y == 14: return ramp(GOLD, 1, face)
        if y < 18: return SOUL[1] if (y == 16 and face == 'front') else ramp(STEEL, 2, face)
        if y == 18: return ramp(GOLD, 1, face)
        return ramp(BONE, 1 if x % 2 else 0, face)
    paint_cube(T, 48, 0, 6, 22, 6, arm)
    paint_cube(T, 72, 0, 6, 22, 6, arm)

    # Legs (7x16x7): steel tasset, bone thigh, gold knee, steel greave and dark boot.
    def leg(face, x, y, fw, fh):
        if face == 'top': return STEEL[2]
        if face == 'bottom': return STEEL[0]
        if y < 4: return ramp(STEEL, 2, face)
        if y == 4: return ramp(GOLD, 1, face)
        if y < 7: return ramp(BONE, 1, face)
        if y < 9: return ramp(GOLD, 2 if y == 7 else 1, face)
        if y < 13: return SOUL[1] if (y == 10 and face == 'front' and x == 3) else ramp(STEEL, 2, face)
        return ramp(STEEL, 0 if y == 15 else 1, face)
    paint_cube(T, 48, 28, 7, 16, 7, leg)
    paint_cube(T, 76, 28, 7, 16, 7, leg)
    save_png(T, f'{ASSETS}/textures/entity/hollow_regent.png')

def icon():
    bg = new(128, 128)
    rect(bg, 0, 0, 127, 127, STEEL[0])
    rect(bg, 4, 4, 123, 123, STEEL[1])
    rect(bg, 8, 8, 119, 119, STEEL[0])
    for i in range(0, 128, 16):
        rect(bg, 8 + i // 2, 8, 8 + i // 2, 11, SOUL[0])
    crown = upscale(sprites.crown(), 6)
    bg.alpha_composite(crown, (16, 8))
    sword = upscale(sprites.sword(), 5)
    bg.alpha_composite(sword, (24, 52))
    ing = upscale(sprites.ingot(), 4)
    bg.alpha_composite(ing, (64, 64))
    rect(bg, 8, 112, 119, 114, SOUL[1])
    save_png(bg, f'{ASSETS}/icon.png')

# ======================================================================================================
# Language, recipes, loot tables, tags, worldgen
# ======================================================================================================
def lang():
    write_json(f'{ASSETS}/lang/en_us.json', {
        'itemGroup.reimagined': 'Reimagined',
        'item.reimagined.gravesteel_ingot': 'Gravesteel Ingot',
        'item.reimagined.hollow_crown': 'Hollow Crown',
        'item.reimagined.regent_sigil': "Regent's Sigil",
        'item.reimagined.gravesteel_sword': 'Gravesteel Sword',
        'item.reimagined.gravecleaver': 'Gravecleaver',
        'item.reimagined.gravesteel_spear': 'Gravesteel Spear',
        'item.reimagined.soulfire_staff': 'Soulfire Staff',
        'item.reimagined.gravesteel_helmet': 'Gravesteel Helmet',
        'item.reimagined.gravesteel_chestplate': 'Gravesteel Chestplate',
        'item.reimagined.gravesteel_leggings': 'Gravesteel Leggings',
        'item.reimagined.gravesteel_boots': 'Gravesteel Boots',
        'entity.reimagined.hollow_regent': 'The Hollow Regent',
        'item.reimagined.regent_sigil.tooltip': 'Rebinds the Hollow Regent where you stand.',
        'item.reimagined.regent_sigil.tooltip2': 'Only answers in the dark. Consumed on use.',
        'item.reimagined.gravesteel_sword.tooltip': 'Grave Wave: every 4th hit sweeps nearby enemies.',
        'item.reimagined.gravecleaver.tooltip': 'Right click: Cleave the ground ahead (8s cooldown).',
        'item.reimagined.gravesteel_spear.tooltip': 'Hamstring: hits briefly slow the target.',
        'item.reimagined.soulfire_staff.tooltip': 'Right click: fire a soul lance (range 24, slows).',
        'item.reimagined.gravesteel_armor.tooltip': '2+ pieces: Vault Walker (Haste I below Y 40).',
        'item.reimagined.gravesteel_armor.tooltip2': '4 pieces: Gravebound Resolve (at 30% health: Absorption II, Resistance I).',
        'message.reimagined.sigil_needs_dark': 'The sigil only answers in the dark.',
        'message.reimagined.resolve': 'Gravebound Resolve',
        'message.reimagined.regent_slain': 'The Hollow Regent has fallen.',
        'key.reimagined.hud_settings': 'Open HUD Settings',
    })

def recipe_shaped(name, pattern, key, result, count=1):
    write_json(f'{DATA}/recipe/{name}.json', {
        'type': 'minecraft:crafting_shaped', 'category': 'equipment',
        'pattern': pattern, 'key': key, 'result': {'id': result, 'count': count}})

def recipes():
    I, S = 'reimagined:gravesteel_ingot', 'minecraft:stick'
    recipe_shaped('gravesteel_sword', ['I', 'I', 'S'], {'I': I, 'S': S}, 'reimagined:gravesteel_sword')
    recipe_shaped('gravecleaver', ['II', 'IS', ' S'], {'I': I, 'S': S}, 'reimagined:gravecleaver')
    recipe_shaped('gravesteel_spear', ['  I', ' S ', 'S  '], {'I': I, 'S': S}, 'reimagined:gravesteel_spear')
    recipe_shaped('soulfire_staff', [' EI', ' SE', 'S  '], {'I': I, 'S': S, 'E': 'minecraft:echo_shard'}, 'reimagined:soulfire_staff')
    recipe_shaped('gravesteel_helmet', ['III', 'I I'], {'I': I}, 'reimagined:gravesteel_helmet')
    recipe_shaped('gravesteel_chestplate', ['I I', 'III', 'III'], {'I': I}, 'reimagined:gravesteel_chestplate')
    recipe_shaped('gravesteel_leggings', ['III', 'I I', 'I I'], {'I': I}, 'reimagined:gravesteel_leggings')
    recipe_shaped('gravesteel_boots', ['I I', 'I I'], {'I': I}, 'reimagined:gravesteel_boots')
    # Sigil: rematch loop (spend the crown) or the expensive route for old worlds with no vault.
    recipe_shaped('regent_sigil_from_crown', ['OBO', 'BCB', 'OBO'],
                  {'O': 'minecraft:obsidian', 'B': 'minecraft:bone_block', 'C': 'reimagined:hollow_crown'}, 'reimagined:regent_sigil')
    recipe_shaped('regent_sigil_from_echo', [' E ', 'ONO', ' E '],
                  {'E': 'minecraft:echo_shard', 'O': 'minecraft:obsidian', 'N': 'minecraft:netherite_scrap'}, 'reimagined:regent_sigil')

def count(lo, hi):
    return {'function': 'minecraft:set_count', 'count': {'type': 'minecraft:uniform', 'min': lo, 'max': hi}}

def item_entry(name, weight=None, lo=None, hi=None):
    e = {'type': 'minecraft:item', 'name': name}
    if weight is not None: e['weight'] = weight
    if lo is not None: e['functions'] = [count(lo, hi)]
    return e

def loot():
    write_json(f'{DATA}/loot_table/entities/hollow_regent.json', {
        'type': 'minecraft:entity',
        'pools': [
            {'rolls': 1, 'entries': [item_entry('reimagined:gravesteel_ingot', lo=4, hi=7)]},
            {'rolls': 1, 'entries': [item_entry('reimagined:hollow_crown')]},
            {'rolls': 1, 'entries': [item_entry('reimagined:soulfire_staff', weight=1), {'type': 'minecraft:empty', 'weight': 2}]},
            {'rolls': 1, 'entries': [item_entry('minecraft:echo_shard', lo=1, hi=3)]},
        ]})
    write_json(f'{DATA}/loot_table/chests/regent_vault.json', {
        'type': 'minecraft:chest',
        'pools': [
            {'rolls': {'type': 'minecraft:uniform', 'min': 3, 'max': 5}, 'entries': [
                item_entry('minecraft:bone', 8, 4, 12), item_entry('minecraft:arrow', 8, 6, 16),
                item_entry('minecraft:iron_ingot', 7, 3, 8), item_entry('minecraft:gold_ingot', 5, 2, 5),
                item_entry('minecraft:coal', 6, 4, 10), item_entry('minecraft:lapis_lazuli', 4, 4, 10),
                item_entry('minecraft:golden_apple', 2), item_entry('minecraft:diamond', 3, 1, 2),
                item_entry('minecraft:echo_shard', 1, 1, 2), item_entry('reimagined:gravesteel_ingot', 3, 1, 2),
            ]},
            {'rolls': {'type': 'minecraft:uniform', 'min': 0, 'max': 1}, 'entries': [
                item_entry('minecraft:name_tag', 3), item_entry('minecraft:saddle', 2), item_entry('minecraft:experience_bottle', 4, 2, 5)]},
        ]})

def tags():
    def tag(path, values):
        write_json(path, {'values': values})
    gear = {
        'swords': ['reimagined:gravesteel_sword'], 'axes': ['reimagined:gravecleaver'], 'spears': ['reimagined:gravesteel_spear'],
        'head_armor': ['reimagined:gravesteel_helmet'], 'chest_armor': ['reimagined:gravesteel_chestplate'],
        'leg_armor': ['reimagined:gravesteel_leggings'], 'foot_armor': ['reimagined:gravesteel_boots'],
    }
    for name, values in gear.items():
        tag(f'{MC_DATA}/tags/item/{name}.json', values)
    armor = gear['head_armor'] + gear['chest_armor'] + gear['leg_armor'] + gear['foot_armor']
    weapons = gear['swords'] + gear['axes'] + gear['spears']
    tag(f'{MC_DATA}/tags/item/enchantable/durability.json', armor + weapons + ['reimagined:soulfire_staff'])
    tag(f'{MC_DATA}/tags/item/enchantable/sword.json', gear['swords'])
    tag(f'{MC_DATA}/tags/item/enchantable/sharp_weapon.json', gear['swords'] + gear['axes'])
    tag(f'{MC_DATA}/tags/item/enchantable/weapon.json', weapons)
    tag(f'{MC_DATA}/tags/item/enchantable/fire_aspect.json', weapons)
    tag(f'{MC_DATA}/tags/item/enchantable/armor.json', armor)
    for name in ('head_armor', 'chest_armor', 'leg_armor', 'foot_armor'):
        tag(f'{MC_DATA}/tags/item/enchantable/{name}.json', gear[name])
    tag(f'{DATA}/tags/item/repairs_gravesteel_gear.json', ['reimagined:gravesteel_ingot'])
    tag(f'{DATA}/tags/block/incorrect_for_gravesteel_tool.json', ['#minecraft:incorrect_for_iron_tool'])

def worldgen():
    write_json(f'{DATA}/worldgen/configured_feature/regent_vault.json', {'type': 'reimagined:regent_vault', 'config': {}})
    write_json(f'{DATA}/worldgen/placed_feature/regent_vault_placed.json', {
        'feature': 'reimagined:regent_vault',
        'placement': [{'type': 'minecraft:rarity_filter', 'chance': 48}, {'type': 'minecraft:in_square'}, {'type': 'minecraft:biome'}]})

if __name__ == '__main__':
    item_files(); armor_layers(); regent_texture(); icon(); lang(); recipes(); loot(); tags(); worldgen()
    print('assets generated')
