# Reimagined (Fabric, Minecraft Java 26.3)

A cohesive extension of vanilla built around one idea: **something ancient is buried under the world, and what you take from it changes how you fight, explore and play.** This is **Phase 1**: a complete, connected vertical slice (boss + structure + gear + HUD), designed so the remaining bosses plug into the same systems.

> **Status, please read:** the code was written against Fabric's own compiled 26.x reference sources and checked for syntax, imports and asset validity, but **it has not been compiled or launched** (the authoring environment cannot reach Mojang/Fabric Maven). Expect to fix a handful of compile errors on first build, most likely in the nine class paths listed under [First-build checklist](#first-build-checklist). Please send me the first error output and I will fix it.

## Build and run

Requirements: **JDK 25**, internet access (Gradle downloads Minecraft, Loom and Fabric API).

```
./gradlew build          # jar in build/libs/reimagined-0.1.0.jar
./gradlew runClient      # dev client with the mod loaded
./gradlew runServer      # dev dedicated server
```

Install: put the jar and **Fabric API 0.165.0+26.3** (or newer for 26.3) in `.minecraft/mods` with **Fabric Loader 0.20.1+**. The mod is required on both client and server.

Versions live in `gradle.properties` (`minecraft_version=26.3`, `fabric_api_version=0.165.0+26.3`, `loom_version=1.19-SNAPSHOT`, `loader_version=0.20.1`). Taken from Fabric's current example mod; check <https://fabricmc.net/develop> for newer values. Targeting 26.2 means changing those four lines and fixing whatever the 26.3 API drift breaks.

## What is in Phase 1

### The Hollow Regent (boss)
A dead king, 2.75 blocks tall, seated on a throne in a buried vault. 300 HP, armour 8, immune to knockback and fire.

| Stage | Behaviour |
|---|---|
| **Dormant** | Seated, invulnerable. Wakes when a player comes within 11 blocks (or instantly via a Sigil). |
| **Awakening** | 3.5 seconds of rising soul flame, then a shockwave. |
| **Phase I** (100 to 66%) | Melee plus **Grave Slam**: arms rise, a ring of soul fire marks the danger radius (6 blocks), then everything *on the ground* takes damage. Jump to avoid it. |
| **Phase II** (66 to 33%) | Adds **Wraith Barrage** (five beams are drawn on the floor first, then fired along those exact lines; sidestep) and **Call of the Fallen** (skeleton guards, max 2 at a time). |
| **Phase III** (below 33%) | Faster, slam radius 8, seven-beam barrage, up to 4 guards, shorter cooldowns. |

Every attack has a visible, audible wind-up. Crossing a phase threshold triggers a brief invulnerable roar that pushes everyone back so players can reset. A single hit can never exceed 40 damage (config). If it loses its target it slowly regenerates. Guards despawn when it dies.

Loot: 4 to 7 Gravesteel Ingots, a **Hollow Crown** (trophy and rematch fuel), 1-in-3 chance of a **Soulfire Staff**, 1 to 3 Echo Shards, 800 XP.

### The Regent's Vault (structure)
A 17x17 deepslate crypt 24 to 48 blocks under the surface (about 1 per 48 chunks, any overworld biome except where the surface is ocean), reached by a ladder shaft that ends in a lantern-lit well-head. Inside: the dormant boss on a dais, two loot chests, soul lanterns, cobwebs and bones. It is built by a Java `Feature` that stays within one chunk of its origin and clears space before building walls (fluids cannot leak in).

### Gravesteel gear (between iron and diamond)
| Item | Notes |
|---|---|
| **Gravesteel Sword** | Vanilla sword stats (+2.5 material damage). **Grave Wave:** every 4th hit sweeps nearby enemies. |
| **Gravecleaver** (axe) | Still strips logs and disables shields. **Right click: Cleave**, a ground strike in front of you (7 damage, knockback, 8s cooldown). |
| **Gravesteel Spear** | Uses vanilla spear mechanics (lunge etc). **Hamstring:** hits briefly slow the target. |
| **Soulfire Staff** | Magic hit-scan lance, range 24, 9 damage, slows, 1.5s cooldown, 256 uses. |
| **Armour** | Defence 3/7/5/3 (iron 15, diamond 20), toughness 1. **2+ pieces:** Haste I below Y 40. **4 pieces: Gravebound Resolve:** at 30% health gain Absorption II and Resistance I (45s cooldown). |
| **Regent's Sigil** | Rebinds the boss where you stand (underground only). Craft from a Hollow Crown + obsidian + bone blocks (rematch loop), or from echo shards + obsidian + netherite scrap (for worlds without a vault). |

Vanilla gear stays relevant: Gravesteel is a sidegrade tier, the staff is a utility weapon, nothing is crafted from other new mats beyond the boss drops. All gear works with vanilla enchanting and anvils via the standard tags.

### HUD (client, press **H**)
Flat pixel-art styling with no gradients. Every element can be toggled and falls back to the vanilla version when off.

* Health, hunger and armour redesigned (poison, wither, hunger, absorption and low-health states are visible), plus a restyled level badge.
* Boss bar for Reimagined bosses with phase markers at 66% and 33%, phase name and percentage.
* Attack cooldown bar and weapon durability under the crosshair.
* Status effects with icon, name, level and countdown (flashes in the last 10 seconds).
* Optional coordinates, biome name and compass (headings every 15 degrees). Info panel can sit in any corner. Four accent colours.

Config files: `config/reimagined.json` (boss health and damage multipliers, per-hit damage cap, armour bonuses, vault generation) and `config/reimagined_hud.json`.

## Progression

```
Vanilla progression
   -> iron/diamond, caves (look for soul-lantern well-heads on the surface)
   -> Regent's Vault -> Hollow Regent
        -> Gravesteel gear (iron to diamond tier), Echo Shards, Hollow Crown
        -> Sigil rematches for more ingots (crown + obsidian + bone blocks)
   -> (Phase 2+) later bosses consume Gravesteel and Echo Shards for their own gear
```

Existing worlds: vaults only appear in **newly generated chunks** (a normal limitation of world generation), so in an explored world use the Sigil (echo shard recipe) or travel to fresh terrain. Everything else (items, boss, HUD) works anywhere. Multiplayer: server-authoritative boss logic, custom packets are registered; mod required on both sides.

## Testing checklist
```
/give @s reimagined:regent_sigil          # then use it on a block in a cave
/summon reimagined:hollow_regent          # dormant, wakes when you approach
/give @s reimagined:gravesteel_sword      # etc, or open the "Reimagined" creative tab
/locate feature reimagined:regent_vault_placed    # may not work for features; use a fresh world and dig around wells
```
Walk through: awakening, each phase, the phase roar, the guards, death loot, the HUD settings screen, armour set bonus at low health, Soulfire Staff, Cleave, Grave Wave.

## First-build checklist
These class paths are standard vanilla but were **not** confirmed by any 26.x source available during authoring; if the compiler rejects an import, search the new package for the class name:
`world.RandomizableContainer`, `world.entity.ExperienceOrb`, `world.entity.ai.goal.MeleeAttackGoal`, `...goal.WaterAvoidingRandomStrollGoal`, `...goal.target.HurtByTargetGoal`, `...goal.target.NearestAttackableTargetGoal`, `world.level.ClipContext`, `...levelgen.feature.FeaturePlaceContext`, `...feature.configurations.NoneFeatureConfiguration`.

Other things that rely on APIs I could not see in the reference sources (verify if something misbehaves): `ItemCooldowns.addCooldown(ItemStack, int)` / `isOnCooldown(ItemStack)`, `MobEffect.isBeneficial()`, `Entity.push`, `LivingEntity.knockback`, `ServerLevel.sendParticles`, sound names (`WARDEN_EMERGE`, `WARDEN_SONIC_BOOM`, `RAVAGER_ROAR`, `EVOKER_*`), `EntityTypes.SKELETON`, the `minecraft:select`/`display_context` spear item definition, and the exact `shouldDespawnInPeaceful` name (intentionally not annotated with `@Override`).

## Project layout
```
src/main/java/dev/reimagined/   ReimaginedMod, config/, entity/, item/, combat/, network/, world/
src/client/java/dev/reimagined/client/   ReimaginedClient, entity/ (model, renderer), hud/
src/main/resources/             fabric.mod.json, assets/ (textures, models, lang), data/ (recipes, loot, tags, worldgen)
tools/                          pixel.py, sprites.py, generate_assets.py (regenerates every texture and JSON file)
```
All textures are original, procedurally drawn with hand-placed pixels and fixed ramps (`python3 tools/generate_assets.py`, needs Pillow). Only vanilla blocks, sounds and particles are reused; nothing is taken from other mods.

## Roadmap (Phase 2 onward)
Designed to reuse the same boss framework (dormant, awaken, phases, telegraphed abilities, payload boss bar, capped damage) and the vault feature pattern.

| # | Boss | Home | Style | Difficulty | Reward |
|---|---|---|---|---|---|
| 2 | **The Drowned Cantor** | Flooded vault under oceans/rivers | Sound-based: expanding sonic rings, tidal pulls, summoned drowned choir | Medium | Tidecaller trident-class weapon, water-breathing armour set |
| 3 | **Emberwake Colossus** | Nether, basalt deltas forge | Slow heavy slams, lava geysers on a visible grid | Hard | Ember weapons, fire-resist set, lava-walking boots |
| 4 | **The Pale Matron** | Dark forest/swamp cellars | Illusions (decoy clones), web traps, poison clouds | Medium-hard | Bow line (Bonebow), stealth armour |
| 5 | **Stormglass Sentinel** | Mountain peak spire | Aerial: lightning telegraphs, wind knockback, tether pylons | Hardest | Elytra-compatible wings upgrade, final armour tier |

Also planned: a retextured set of selected vanilla items and blocks in the same palette (texture overhaul), a custom bow (vanilla `BowItem` with pull-stage item definitions), custom sounds, a biome-aware loot layer for vaults, and an advancements tree.

## License
MIT. See `LICENSE`.
