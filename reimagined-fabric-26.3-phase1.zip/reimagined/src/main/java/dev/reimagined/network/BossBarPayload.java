package dev.reimagined.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

import dev.reimagined.ReimaginedMod;

/**
 * Server to client boss status, sent a few times per second to everyone tracking a Reimagined boss.
 * Reimagined bosses deliberately do not use vanilla boss events: this lets the client draw the custom
 * boss bar with phase markers and know when the boss is dormant.
 */
public record BossBarPayload(int entityId, float health, float maxHealth, int phase, int state) implements CustomPacketPayload {
	public static final CustomPacketPayload.Type<BossBarPayload> TYPE = new CustomPacketPayload.Type<>(ReimaginedMod.id("boss_bar"));
	public static final StreamCodec<RegistryFriendlyByteBuf, BossBarPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, BossBarPayload::entityId,
			ByteBufCodecs.FLOAT, BossBarPayload::health,
			ByteBufCodecs.FLOAT, BossBarPayload::maxHealth,
			ByteBufCodecs.VAR_INT, BossBarPayload::phase,
			ByteBufCodecs.VAR_INT, BossBarPayload::state,
			BossBarPayload::new
	);

	@Override
	public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
