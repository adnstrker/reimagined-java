package dev.reimagined.item;

import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import dev.reimagined.combat.CombatEvents;

/**
 * Gravecleaver: a heavy axe. Besides being a good axe (it still strips logs and breaks shields), right
 * clicking in the air performs a Cleave: a short-range ground strike that damages and shoves everything
 * in front of the player. 8 second cooldown, costs two durability.
 */
public class GravecleaverItem extends AxeItem {
	private static final int COOLDOWN_TICKS = 160;
	private static final float DAMAGE = 7.0F;

	public GravecleaverItem(ToolMaterial material, float attackDamage, float attackSpeed, Properties properties) {
		super(material, attackDamage, attackSpeed, properties);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (player.getCooldowns().isOnCooldown(stack)) {
			return InteractionResult.FAIL;
		}
		if (level instanceof ServerLevel serverLevel) {
			Vec3 forward = player.getLookAngle().multiply(1.0, 0.0, 1.0);
			forward = forward.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : forward.normalize();
			Vec3 center = player.position().add(forward.scale(2.4));

			AABB area = new AABB(center, center).inflate(2.6, 1.6, 2.6);
			CombatEvents.runAbility(() -> {
				for (LivingEntity target : serverLevel.getEntitiesOfClass(LivingEntity.class, area, e -> e != player && e.isAlive() && !e.isAlliedTo(player))) {
					target.hurtServer(serverLevel, serverLevel.damageSources().playerAttack(player), DAMAGE);
					target.knockback(0.9, player.getX() - target.getX(), player.getZ() - target.getZ());
				}
			});

			for (int i = 0; i < 14; i++) {
				double angle = i / 14.0 * Math.PI * 2.0;
				serverLevel.sendParticles(ParticleTypes.POOF, center.x + Math.cos(angle) * 2.2, player.getY() + 0.1, center.z + Math.sin(angle) * 2.2, 1, 0.1, 0.05, 0.1, 0.02);
			}
			serverLevel.sendParticles(ParticleTypes.EXPLOSION, center.x, player.getY() + 0.3, center.z, 1, 0.0, 0.0, 0.0, 0.0);
			serverLevel.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.6F, 0.7F);

			stack.hurtAndBreak(2, player, hand);
			player.getCooldowns().addCooldown(stack, COOLDOWN_TICKS);
		}
		player.swing(hand);
		return InteractionResult.SUCCESS;
	}

	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay displayComponent, Consumer<Component> textConsumer, TooltipFlag type) {
		textConsumer.accept(Component.translatable("item.reimagined.gravecleaver.tooltip").withStyle(ChatFormatting.GOLD));
	}
}
