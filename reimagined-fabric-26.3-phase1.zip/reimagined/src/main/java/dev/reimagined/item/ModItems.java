package dev.reimagined.item;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.equipment.ArmorType;

import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;

import dev.reimagined.ReimaginedMod;

public final class ModItems {
	// ---- Materials and trophies -------------------------------------------------------------------------
	public static final Item GRAVESTEEL_INGOT = register("gravesteel_ingot", Item::new, new Item.Properties());
	public static final Item HOLLOW_CROWN = register("hollow_crown", Item::new, new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
	public static final Item REGENT_SIGIL = register("regent_sigil", RegentSigilItem::new, new Item.Properties().stacksTo(16).rarity(Rarity.RARE));

	// ---- Weapons ----------------------------------------------------------------------------------------
	public static final Item GRAVESTEEL_SWORD = register("gravesteel_sword", Item::new, new Item.Properties().sword(GravesteelMaterials.TOOL, 3.0F, -2.4F)
					.component(DataComponents.LORE, lore("item.reimagined.gravesteel_sword.tooltip")));
	public static final Item GRAVECLEAVER = register("gravecleaver",
			settings -> new GravecleaverItem(GravesteelMaterials.TOOL, 5.5F, -3.1F, settings),
			new Item.Properties());
	public static final Item GRAVESTEEL_SPEAR = register("gravesteel_spear", Item::new,
			new Item.Properties().spear(GravesteelMaterials.TOOL, 2.8f, 0.3f, 1.4f, 1.1f, 2.0f, 1.1f, 0.15f, 0.25f, 0.45f)
					.component(DataComponents.LORE, lore("item.reimagined.gravesteel_spear.tooltip")));
	public static final Item SOULFIRE_STAFF = register("soulfire_staff", SoulfireStaffItem::new,
			new Item.Properties().durability(256).rarity(Rarity.RARE));

	// ---- Armour -----------------------------------------------------------------------------------------
	public static final Item GRAVESTEEL_HELMET = register("gravesteel_helmet", Item::new,
			new Item.Properties().humanoidArmor(GravesteelMaterials.ARMOR, ArmorType.HELMET)
					.component(DataComponents.LORE, lore("item.reimagined.gravesteel_armor.tooltip", "item.reimagined.gravesteel_armor.tooltip2")));
	public static final Item GRAVESTEEL_CHESTPLATE = register("gravesteel_chestplate", Item::new,
			new Item.Properties().humanoidArmor(GravesteelMaterials.ARMOR, ArmorType.CHESTPLATE)
					.component(DataComponents.LORE, lore("item.reimagined.gravesteel_armor.tooltip", "item.reimagined.gravesteel_armor.tooltip2")));
	public static final Item GRAVESTEEL_LEGGINGS = register("gravesteel_leggings", Item::new,
			new Item.Properties().humanoidArmor(GravesteelMaterials.ARMOR, ArmorType.LEGGINGS)
					.component(DataComponents.LORE, lore("item.reimagined.gravesteel_armor.tooltip", "item.reimagined.gravesteel_armor.tooltip2")));
	public static final Item GRAVESTEEL_BOOTS = register("gravesteel_boots", Item::new,
			new Item.Properties().humanoidArmor(GravesteelMaterials.ARMOR, ArmorType.BOOTS)
					.component(DataComponents.LORE, lore("item.reimagined.gravesteel_armor.tooltip", "item.reimagined.gravesteel_armor.tooltip2")));

	// ---- Creative tab -----------------------------------------------------------------------------------
	public static final ResourceKey<CreativeModeTab> TAB_KEY = ResourceKey.create(BuiltInRegistries.CREATIVE_MODE_TAB.key(), ReimaginedMod.id("reimagined"));
	public static final CreativeModeTab TAB = FabricCreativeModeTab.builder()
			.icon(() -> new ItemStack(ModItems.GRAVESTEEL_SWORD))
			.title(Component.translatable("itemGroup.reimagined"))
			.displayItems((params, output) -> {
				output.accept(GRAVESTEEL_INGOT);
				output.accept(HOLLOW_CROWN);
				output.accept(REGENT_SIGIL);
				output.accept(GRAVESTEEL_SWORD);
				output.accept(GRAVECLEAVER);
				output.accept(GRAVESTEEL_SPEAR);
				output.accept(SOULFIRE_STAFF);
				output.accept(GRAVESTEEL_HELMET);
				output.accept(GRAVESTEEL_CHESTPLATE);
				output.accept(GRAVESTEEL_LEGGINGS);
				output.accept(GRAVESTEEL_BOOTS);
			})
			.build();

	/** Tooltip lines (translation keys) shown in aqua, not in the default italic purple of lore. */
	private static ItemLore lore(String... keys) {
		List<Component> lines = new ArrayList<>();
		for (String key : keys) {
			lines.add(Component.translatable(key).withStyle(Style.EMPTY.withItalic(false).withColor(ChatFormatting.AQUA)));
		}
		return new ItemLore(lines);
	}

	private static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties settings) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ReimaginedMod.id(name));
		Item item = factory.apply(settings.setId(key));
		return Registry.register(BuiltInRegistries.ITEM, key, item);
	}

	public static void initialize() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_KEY, TAB);

		// Also surface the gear where players already look for it.
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(tab -> {
			tab.accept(GRAVESTEEL_SWORD);
			tab.accept(GRAVECLEAVER);
			tab.accept(GRAVESTEEL_SPEAR);
			tab.accept(SOULFIRE_STAFF);
			tab.accept(GRAVESTEEL_HELMET);
			tab.accept(GRAVESTEEL_CHESTPLATE);
			tab.accept(GRAVESTEEL_LEGGINGS);
			tab.accept(GRAVESTEEL_BOOTS);
		});
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS).register(tab -> {
			tab.accept(GRAVESTEEL_INGOT);
			tab.accept(HOLLOW_CROWN);
		});
	}

	private ModItems() {
	}
}
