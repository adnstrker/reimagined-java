package dev.reimagined.item;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Soulfire Staff: a hit-scan magic weapon. Right click fires a lance of soul fire that damages and
 * slows the first creature in line (range 24). 1.5 second cooldown, costs one durability per cast.
 */
public class SoulfireStaffItem extends Item {
	private static final double RANGE = 24.0;
	private static final float DAMAGE = 9.0F;
	private static final int COOLDOWN_TICKS = 30;

	public SoulfireStaffItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (player.getCooldowns().isOnCooldown(stack)) {
			return InteractionResult.FAIL;
		}
		if (level instanceof ServerLevel serverLevel) {
			Vec3 start = player.getEyePosition();
			Vec3 look = player.getLookAngle();
			Vec3 end = start.add(look.scale(RANGE));

			// Stop at the first solid block.
			Vec3 blockHit = serverLevel.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player)).getLocation();
			double maxDistance = start.distanceTo(blockHit);
			Vec3 stop = start.add(look.scale(maxDistance));

			List<LivingEntity> candidates = serverLevel.getEntitiesOfClass(
					LivingEntity.class,
					new AABB(start, stop).inflate(1.5),
					e -> e != player && e.isAlive() && !e.isAlliedTo(player)
			);
			Optional<LivingEntity> target = candidates.stream()
					.filter(e -> e.getBoundingBox().inflate(0.4).clip(start, stop).isPresent())
					.min(Comparator.comparingDouble(e -> e.distanceToSqr(start)));

			double length = maxDistance;
			if (target.isPresent()) {
				LivingEntity victim = target.get();
				length = Math.min(maxDistance, start.distanceTo(victim.getBoundingBox().getCenter()));
				victim.hurtServer(serverLevel, serverLevel.damageSources().magic(), DAMAGE);
				victim.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 0));
				serverLevel.sendParticles(ParticleTypes.SOUL, victim.getX(), victim.getY() + victim.getBbHeight() * 0.5, victim.getZ(), 12, 0.3, 0.4, 0.3, 0.05);
			}
			for (double d = 1.0; d < length; d += 0.6) {
				Vec3 p = start.add(look.scale(d));
				serverLevel.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, p.x, p.y - 0.15, p.z, 1, 0.03, 0.03, 0.03, 0.0);
			}
			serverLevel.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 0.8F, 1.6F);

			stack.hurtAndBreak(1, player, hand);
			player.getCooldowns().addCooldown(stack, COOLDOWN_TICKS);
		}
		player.swing(hand);
		return InteractionResult.SUCCESS;
	}

	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay displayComponent, Consumer<Component> textConsumer, TooltipFlag type) {
		textConsumer.accept(Component.translatable("item.reimagined.soulfire_staff.tooltip").withStyle(ChatFormatting.AQUA));
	}
}
