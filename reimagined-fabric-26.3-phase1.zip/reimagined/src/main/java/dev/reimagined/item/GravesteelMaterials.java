package dev.reimagined.item;

import java.util.Map;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;
import net.minecraft.world.level.block.Block;

import dev.reimagined.ReimaginedMod;

/**
 * Gravesteel sits between iron and diamond: sturdier than iron, a little softer than diamond,
 * and it cannot be crafted until the Hollow Regent has been defeated at least once.
 */
public final class GravesteelMaterials {
	public static final TagKey<Block> INCORRECT_BLOCKS_FOR_TOOL = TagKey.create(Registries.BLOCK, ReimaginedMod.id("incorrect_for_gravesteel_tool"));
	public static final TagKey<Item> REPAIRS_GRAVESTEEL_GEAR = TagKey.create(BuiltInRegistries.ITEM.key(), ReimaginedMod.id("repairs_gravesteel_gear"));

	/** durability, mining speed, attack damage bonus, enchantability. (iron: 250/6/2/14, diamond: 1561/8/3/10) */
	public static final ToolMaterial TOOL = new ToolMaterial(INCORRECT_BLOCKS_FOR_TOOL, 820, 7.0F, 2.5F, 14, REPAIRS_GRAVESTEEL_GEAR);

	public static final ResourceKey<EquipmentAsset> ARMOR_ASSET = ResourceKey.create(EquipmentAssets.ROOT_ID, ReimaginedMod.id("gravesteel"));

	/** Total defence 18 (iron 15, diamond 20), toughness 1, a little knockback resistance. */
	public static final ArmorMaterial ARMOR = new ArmorMaterial(
			24,
			Map.of(ArmorType.HELMET, 3, ArmorType.CHESTPLATE, 7, ArmorType.LEGGINGS, 5, ArmorType.BOOTS, 3),
			12,
			SoundEvents.ARMOR_EQUIP_IRON,
			1.0F,
			0.05F,
			REPAIRS_GRAVESTEEL_GEAR,
			ARMOR_ASSET
	);

	private GravesteelMaterials() {
	}
}
