package dev.reimagined.item;

import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.context.UseOnContext;

import dev.reimagined.entity.HollowRegentEntity;
import dev.reimagined.entity.ModEntities;

/**
 * Rebinds the Hollow Regent. This is the way to fight the boss in worlds whose chunks were generated
 * before the mod was installed (vaults only appear in newly generated terrain), and the way to
 * rematch it after the first victory. Consumed on use; only answers in the dark.
 */
public class RegentSigilItem extends Item {
	public RegentSigilItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		if (!(context.getLevel() instanceof ServerLevel level)) {
			return InteractionResult.SUCCESS;
		}
		Player player = context.getPlayer();
		BlockPos pos = context.getClickedPos().relative(context.getClickedFace());

		if (level.canSeeSky(pos)) {
			if (player != null) {
				player.displayClientMessage(Component.translatable("message.reimagined.sigil_needs_dark").withStyle(ChatFormatting.GRAY), true);
			}
			return InteractionResult.FAIL;
		}

		HollowRegentEntity boss = ModEntities.HOLLOW_REGENT.create(level, EntitySpawnReason.MOB_SUMMONED);
		if (boss == null) {
			return InteractionResult.FAIL;
		}
		boss.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
		boss.setYRot(player != null ? player.getYRot() + 180.0F : 0.0F);
		boss.setPersistenceRequired();
		boss.beginAwakening();
		level.addFreshEntity(boss);

		if (player != null && !player.getAbilities().instabuild) {
			context.getItemInHand().shrink(1);
		}
		return InteractionResult.SUCCESS;
	}

	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, TooltipDisplay displayComponent, Consumer<Component> textConsumer, TooltipFlag type) {
		textConsumer.accept(Component.translatable("item.reimagined.regent_sigil.tooltip").withStyle(ChatFormatting.DARK_AQUA));
		textConsumer.accept(Component.translatable("item.reimagined.regent_sigil.tooltip2").withStyle(ChatFormatting.GRAY));
	}
}
