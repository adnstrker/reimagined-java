package dev.reimagined.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.storage.loot.LootTable;

import dev.reimagined.ReimaginedMod;
import dev.reimagined.config.ReimaginedConfig;
import dev.reimagined.entity.HollowRegentEntity;
import dev.reimagined.entity.ModEntities;

/**
 * The Regent's Vault: a 17x17 deepslate crypt buried 24 to 48 blocks below the surface, reached by a
 * ladder shaft that ends in a small lantern-lit well-head on the surface. Inside: a seated, dormant
 * Hollow Regent on a dais, two loot chests, soul lanterns, cobwebs and bones.
 *
 * <p>Everything is placed relative to the middle of the chunk the feature runs in and stays within
 * 8 blocks of it horizontally, so it never reaches further than the neighbouring chunks (a worldgen
 * requirement). Space is cleared first, then the shell is built, so water and lava never intrude.
 */
public class RegentVaultFeature extends Feature<NoneFeatureConfiguration> {
	private static final ResourceKey<LootTable> VAULT_LOOT = ResourceKey.create(Registries.LOOT_TABLE, ReimaginedMod.id("chests/regent_vault"));
	private static final int HALF = 8;
	private static final int HEIGHT = 9;

	public RegentVaultFeature() {
		super(NoneFeatureConfiguration.CODEC);
	}

	@Override
	public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
		if (!ReimaginedConfig.get().generateVaults) {
			return false;
		}
		WorldGenLevel level = context.level();
		RandomSource random = context.random();
		ChunkPos chunk = new ChunkPos(context.origin());
		int cx = chunk.getMiddleBlockX();
		int cz = chunk.getMiddleBlockZ();

		int surface = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, cx, cz);
		int shaftSurface = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, cx, cz + 6);
		if (surface <= level.getSeaLevel() + 2 || shaftSurface <= level.getSeaLevel() + 1) {
			return false; // oceans, rivers and beaches: no entrance hidden underwater
		}
		int floorY = Mth.clamp(surface - 24 - random.nextInt(25), level.getMinY() + 10, 30);
		if (shaftSurface - floorY < 16) {
			return false;
		}

		buildShell(level, random, cx, floorY, cz);
		buildFloor(level, random, cx, floorY, cz);
		buildDecor(level, random, cx, floorY, cz);
		buildShaft(level, random, cx, floorY, cz, shaftSurface);

		HollowRegentEntity boss = ModEntities.HOLLOW_REGENT.create(level.getLevel(), EntitySpawnReason.STRUCTURE);
		if (boss != null) {
			boss.setPos(cx + 0.5, floorY + 0.5, cz - 6.0);
			boss.setYRot(0.0F);
			boss.setYBodyRot(0.0F);
			boss.setYHeadRot(0.0F);
			boss.setPersistenceRequired();
			level.addFreshEntityWithPassengers(boss);
		}
		return true;
	}

	// ---- Construction -----------------------------------------------------------------------------------

	private static void buildShell(WorldGenLevel level, RandomSource random, int cx, int y0, int cz) {
		for (int dx = -HALF; dx <= HALF; dx++) {
			for (int dz = -HALF; dz <= HALF; dz++) {
				boolean edge = Math.abs(dx) == HALF || Math.abs(dz) == HALF;
				for (int dy = 0; dy <= HEIGHT; dy++) {
					boolean ceiling = dy == HEIGHT;
					BlockState state = (edge || ceiling) ? bricks(random) : Blocks.AIR.defaultBlockState();
					set(level, cx + dx, y0 + dy, cz + dz, state);
				}
			}
		}
	}

	private static void buildFloor(WorldGenLevel level, RandomSource random, int cx, int y0, int cz) {
		for (int dx = -HALF; dx <= HALF; dx++) {
			for (int dz = -HALF; dz <= HALF; dz++) {
				int ring = Math.max(Math.abs(dx), Math.abs(dz));
				BlockState state;
				if (ring == 2) {
					state = Blocks.CHISELED_DEEPSLATE.defaultBlockState();
				} else if (ring == 0) {
					state = Blocks.SOUL_SAND.defaultBlockState();
				} else if (random.nextInt(6) == 0) {
					state = Blocks.CRACKED_DEEPSLATE_TILES.defaultBlockState();
				} else {
					state = ((dx + dz) & 1) == 0 ? Blocks.POLISHED_DEEPSLATE.defaultBlockState() : Blocks.DEEPSLATE_TILES.defaultBlockState();
				}
				set(level, cx + dx, y0 - 1, cz + dz, state);
			}
		}
	}

	private static void buildDecor(WorldGenLevel level, RandomSource random, int cx, int y0, int cz) {
		// Pillars with chiseled caps in the four inner corners.
		for (int sx = -1; sx <= 1; sx += 2) {
			for (int sz = -1; sz <= 1; sz += 2) {
				for (int dy = 0; dy < HEIGHT; dy++) {
					BlockState state = dy == 0 || dy == HEIGHT - 1 ? Blocks.CHISELED_DEEPSLATE.defaultBlockState() : Blocks.POLISHED_DEEPSLATE.defaultBlockState();
					set(level, cx + sx * 4, y0 + dy, cz + sz * 4, state);
				}
			}
		}

		// Dais for the throne: bottom slabs 3 wide, two deep, against the north wall; chiseled backing in the wall.
		BlockState slab = Blocks.DEEPSLATE_BRICK_SLAB.defaultBlockState().setValue(BlockStateProperties.SLAB_TYPE, SlabType.BOTTOM);
		for (int dx = -1; dx <= 1; dx++) {
			set(level, cx + dx, y0, cz - 7, slab);
			set(level, cx + dx, y0, cz - 6, slab);
		}
		for (int dy = 1; dy <= 4; dy++) {
			set(level, cx, y0 + dy, cz - HALF, Blocks.CHISELED_DEEPSLATE.defaultBlockState());
		}
		set(level, cx - 1, y0 + 4, cz - HALF, Blocks.SOUL_LANTERN.defaultBlockState());

		// Soul lanterns along the side walls.
		for (int sx = -1; sx <= 1; sx += 2) {
			for (int dz = -3; dz <= 3; dz += 6) {
				set(level, cx + sx * 6, y0, cz + dz, Blocks.SOUL_LANTERN.defaultBlockState());
			}
		}

		// Two chests in the south corners, facing into the room.
		BlockState chest = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.NORTH);
		for (int sx = -1; sx <= 1; sx += 2) {
			BlockPos pos = new BlockPos(cx + sx * 6, y0, cz + 6);
			set(level, pos.getX(), pos.getY(), pos.getZ(), chest);
			RandomizableContainer.setBlockEntityLootTable(level, random, pos, VAULT_LOOT);
		}

		// Ruin dressing: cobwebs under the ceiling, scattered bone blocks.
		for (int i = 0; i < 14; i++) {
			int dx = random.nextInt(2 * HALF - 1) - (HALF - 1);
			int dz = random.nextInt(2 * HALF - 1) - (HALF - 1);
			if (Math.abs(dx) >= 6 || Math.abs(dz) >= 6) {
				set(level, cx + dx, y0 + HEIGHT - 1, cz + dz, Blocks.COBWEB.defaultBlockState());
			}
		}
		for (int i = 0; i < 7; i++) {
			int dx = random.nextInt(2 * HALF - 1) - (HALF - 1);
			int dz = random.nextInt(2 * HALF - 1) - (HALF - 1);
			if (Math.abs(dx) >= 5 && Math.abs(dz) < 5) {
				set(level, cx + dx, y0, cz + dz, Blocks.BONE_BLOCK.defaultBlockState());
			}
		}
	}

	/**
	 * A 3x3 shaft (ringed by brick walls) above the south end of the room, with a ladder climbing the
	 * south wall from the vault floor to the surface, finished with four wall posts and lanterns.
	 */
	private static void buildShaft(WorldGenLevel level, RandomSource random, int cx, int y0, int cz, int surface) {
		for (int y = y0 + HEIGHT; y <= surface + 3; y++) {
			for (int dx = -2; dx <= 2; dx++) {
				for (int dz = 4; dz <= HALF; dz++) {
					boolean inside = dx >= -1 && dx <= 1 && dz >= 5 && dz <= 7;
					if (inside) {
						set(level, cx + dx, y, cz + dz, Blocks.AIR.defaultBlockState());
					} else if (y < surface) {
						set(level, cx + dx, y, cz + dz, bricks(random));
					}
				}
			}
		}
		BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.NORTH);
		for (int y = y0; y <= surface; y++) {
			set(level, cx, y, cz + 7, ladder);
		}
		for (int sx = -2; sx <= 2; sx += 4) {
			for (int sz = 4; sz <= HALF; sz += 4) {
				set(level, cx + sx, surface, cz + sz, Blocks.COBBLED_DEEPSLATE_WALL.defaultBlockState());
				set(level, cx + sx, surface + 1, cz + sz, Blocks.COBBLED_DEEPSLATE_WALL.defaultBlockState());
				set(level, cx + sx, surface + 2, cz + sz, Blocks.SOUL_LANTERN.defaultBlockState());
			}
		}
	}

	private static BlockState bricks(RandomSource random) {
		float roll = random.nextFloat();
		if (roll < 0.70F) {
			return Blocks.DEEPSLATE_BRICKS.defaultBlockState();
		}
		return roll < 0.95F ? Blocks.CRACKED_DEEPSLATE_BRICKS.defaultBlockState() : Blocks.COBBLED_DEEPSLATE.defaultBlockState();
	}

	private static void set(WorldGenLevel level, int x, int y, int z, BlockState state) {
		level.setBlock(new BlockPos(x, y, z), state, Block.UPDATE_CLIENTS);
	}
}
