package dev.reimagined.world;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;

import dev.reimagined.ReimaginedMod;

public final class ModWorldgen {
	public static final Feature<NoneFeatureConfiguration> REGENT_VAULT = Registry.register(
			BuiltInRegistries.FEATURE, ReimaginedMod.id("regent_vault"), new RegentVaultFeature());

	/** Defined in data/reimagined/worldgen/placed_feature/regent_vault_placed.json (rarity 1 in 48 chunks). */
	public static final ResourceKey<PlacedFeature> REGENT_VAULT_PLACED = ResourceKey.create(Registries.PLACED_FEATURE, ReimaginedMod.id("regent_vault_placed"));

	public static void initialize() {
		// Adds the vault to every overworld biome. The feature itself skips oceans (see RegentVaultFeature).
		BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Decoration.UNDERGROUND_STRUCTURES, REGENT_VAULT_PLACED);
	}

	private ModWorldgen() {
	}
}
