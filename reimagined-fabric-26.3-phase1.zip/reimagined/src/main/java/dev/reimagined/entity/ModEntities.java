package dev.reimagined.entity;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;

import dev.reimagined.ReimaginedMod;

public final class ModEntities {
	public static final ResourceKey<EntityType<?>> HOLLOW_REGENT_KEY = ResourceKey.create(Registries.ENTITY_TYPE, ReimaginedMod.id("hollow_regent"));

	public static final EntityType<HollowRegentEntity> HOLLOW_REGENT = Registry.register(
			BuiltInRegistries.ENTITY_TYPE,
			HOLLOW_REGENT_KEY,
			EntityType.Builder.<HollowRegentEntity>of(HollowRegentEntity::new, MobCategory.MONSTER)
					.sized(1.7F, 3.0F)
					.clientTrackingRange(10)
					.fireImmune()
					.build(HOLLOW_REGENT_KEY)
	);

	public static void initialize() {
		FabricDefaultAttributeRegistry.register(HOLLOW_REGENT, HollowRegentEntity.createAttributes());
	}

	private ModEntities() {
	}
}
