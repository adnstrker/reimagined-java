package dev.reimagined.entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import dev.reimagined.config.ReimaginedConfig;
import dev.reimagined.network.BossBarPayload;

/**
 * The Hollow Regent: a long-dead king bound to a deep vault.
 *
 * <h2>Lifecycle</h2>
 * Dormant (seated on its throne, invulnerable) -> Awakening (70 ticks) -> Fight. It wakes when any
 * player gets within 11 blocks, or immediately when summoned with a Regent's Sigil.
 *
 * <h2>Phases (by health)</h2>
 * <ul>
 *   <li><b>I (100-66%)</b>: relentless melee and the telegraphed Grave Slam.</li>
 *   <li><b>II (66-33%)</b>: adds Wraith Barrage (fan of beams, sidestep them) and Call of the Fallen
 *       (summons skeleton guards).</li>
 *   <li><b>III (below 33%)</b>: faster, a wider slam, a seven beam barrage, up to three guards at once.</li>
 * </ul>
 * Every ability has a visible wind-up so encounters stay fair; hits are capped (config) and the boss
 * forces a short roar when crossing a phase threshold.
 */
public class HollowRegentEntity extends Monster {
	public static final int STATE_DORMANT = 0;
	public static final int STATE_AWAKENING = 1;
	public static final int STATE_FIGHT = 2;

	public static final int ATTACK_NONE = 0;
	public static final int ATTACK_SLAM = 1;
	public static final int ATTACK_BARRAGE = 2;
	public static final int ATTACK_SUMMON = 3;
	public static final int ATTACK_ROAR = 4;

	public static final int AWAKEN_TICKS = 70;
	public static final int SLAM_TOTAL = 46;
	public static final int SLAM_IMPACT = 30;
	public static final int BARRAGE_TOTAL = 48;
	public static final int BARRAGE_FIRE = 32;
	public static final int SUMMON_TOTAL = 56;
	public static final int SUMMON_SPAWN = 42;
	public static final int ROAR_TOTAL = 56;
	public static final int ROAR_EFFECT = 32;

	private static final double BEAM_LENGTH = 20.0;
	public static final String GUARD_TAG = "reimagined_guard";

	private static final EntityDataAccessor<Integer> DATA_STATE = SynchedEntityData.defineId(HollowRegentEntity.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Integer> DATA_ATTACK = SynchedEntityData.defineId(HollowRegentEntity.class, EntityDataSerializers.INT);

	/** Client-side animation clocks (entity tick at which the current state / attack began). */
	public int stateStartTick;
	public int attackStartTick;

	private int currentAttack = ATTACK_NONE;
	private int attackTimer;
	private int stateTimer;
	private int cooldown = 60;
	private int lastPhase = 1;
	private int idleTicks;
	private final List<Vec3> beams = new ArrayList<>();

	public HollowRegentEntity(EntityType<? extends HollowRegentEntity> type, Level level) {
		super(type, level);
		ReimaginedConfig config = ReimaginedConfig.get();
		AttributeInstance health = getAttribute(Attributes.MAX_HEALTH);
		if (health != null) {
			health.setBaseValue(300.0 * config.bossHealthMultiplier);
		}
		AttributeInstance damage = getAttribute(Attributes.ATTACK_DAMAGE);
		if (damage != null) {
			damage.setBaseValue(14.0 * config.bossDamageMultiplier);
		}
		setHealth(getMaxHealth());
		setPersistenceRequired();
		applyStateFlags(STATE_DORMANT);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Monster.createMonsterAttributes()
				.add(Attributes.MAX_HEALTH, 300.0)
				.add(Attributes.ATTACK_DAMAGE, 14.0)
				.add(Attributes.MOVEMENT_SPEED, 0.26)
				.add(Attributes.FOLLOW_RANGE, 40.0)
				.add(Attributes.ARMOR, 8.0)
				.add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
	}

	// ---- Goals and synced data --------------------------------------------------------------------------

	@Override
	protected void registerGoals() {
		goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, false));
		goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6));
		goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
		goalSelector.addGoal(7, new RandomLookAroundGoal(this));
		targetSelector.addGoal(1, new HurtByTargetGoal(this));
		targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(DATA_STATE, STATE_DORMANT);
		builder.define(DATA_ATTACK, ATTACK_NONE);
	}

	@Override
	public void onSyncedDataUpdated(EntityDataAccessor<?> data) {
		super.onSyncedDataUpdated(data);
		if (data == DATA_STATE) {
			stateStartTick = tickCount;
		} else if (data == DATA_ATTACK) {
			attackStartTick = tickCount;
		}
	}

	public int getState() {
		return entityData.get(DATA_STATE);
	}

	public int getAttackId() {
		return entityData.get(DATA_ATTACK);
	}

	public int getPhase() {
		float fraction = getHealth() / Math.max(1.0F, getMaxHealth());
		return fraction > 0.66F ? 1 : fraction > 0.33F ? 2 : 3;
	}

	private void setState(int state) {
		entityData.set(DATA_STATE, state);
		stateTimer = 0;
		applyStateFlags(state);
	}

	private void applyStateFlags(int state) {
		boolean fighting = state == STATE_FIGHT;
		setNoAi(!fighting);
		setInvulnerable(!fighting);
	}

	/** Starts the awakening sequence if the boss is still dormant. Server side only. */
	public void beginAwakening() {
		if (getState() == STATE_DORMANT) {
			setState(STATE_AWAKENING);
		}
	}

	// ---- Main loop --------------------------------------------------------------------------------------

	@Override
	public void tick() {
		super.tick();
		if (level().isClientSide()) {
			return;
		}
		ServerLevel level = (ServerLevel) level();
		switch (getState()) {
			case STATE_DORMANT -> tickDormant(level);
			case STATE_AWAKENING -> tickAwakening(level);
			default -> tickFight(level);
		}
		if (tickCount % 5 == 0) {
			BossBarPayload payload = new BossBarPayload(getId(), getHealth(), getMaxHealth(), getPhase(), getState());
			for (ServerPlayer player : PlayerLookup.tracking(this)) {
				ServerPlayNetworking.send(player, payload);
			}
		}
	}

	private void tickDormant(ServerLevel level) {
		if (tickCount % 20 == 0) {
			level.sendParticles(ParticleTypes.SOUL, getX(), getY() + 2.2, getZ(), 2, 0.4, 0.4, 0.4, 0.01);
		}
		if (tickCount % 10 == 0) {
			Player nearest = level.getNearestPlayer(this, 11.0);
			if (nearest != null && !nearest.isSpectator()) {
				beginAwakening();
			}
		}
	}

	private void tickAwakening(ServerLevel level) {
		stateTimer++;
		if (stateTimer == 1) {
			playSound(level, SoundEvents.WARDEN_EMERGE, 2.0F, 0.7F);
		}
		if (stateTimer % 4 == 0) {
			ring(level, 1.0 + stateTimer * 0.08, ParticleTypes.SOUL_FIRE_FLAME, 16);
		}
		if (stateTimer >= AWAKEN_TICKS) {
			setState(STATE_FIGHT);
			lastPhase = getPhase();
			pulse(level, 7.0, 0.0F, 1.2, false);
			playSound(level, SoundEvents.WARDEN_ROAR, 3.0F, 0.8F);
		}
	}

	private void tickFight(ServerLevel level) {
		LivingEntity target = getTarget();
		if (target == null || !target.isAlive()) {
			idleTicks++;
			if (idleTicks > 200 && tickCount % 20 == 0 && getHealth() < getMaxHealth()) {
				heal(getMaxHealth() * 0.02F);
			}
		} else {
			idleTicks = 0;
		}

		int phase = getPhase();
		if (currentAttack == ATTACK_NONE) {
			if (phase > lastPhase) {
				lastPhase = phase;
				if (phase == 3) {
					AttributeInstance speed = getAttribute(Attributes.MOVEMENT_SPEED);
					if (speed != null) {
						speed.setBaseValue(0.31);
					}
				}
				startAttack(ATTACK_ROAR);
			} else if (target != null && --cooldown <= 0) {
				chooseAttack(level, target, phase);
			}
		}
		if (currentAttack != ATTACK_NONE) {
			runAttack(level, target, phase);
		}
	}

	private void chooseAttack(ServerLevel level, LivingEntity target, int phase) {
		double distance = distanceTo(target);
		if (phase == 1) {
			if (distance <= 10.0) {
				startAttack(ATTACK_SLAM);
			} else {
				cooldown = 20;
			}
			return;
		}
		int roll = random.nextInt(100);
		boolean canBarrage = distance >= 5.0 && hasLineOfSight(target);
		boolean canSummon = countGuards(level) < (phase == 3 ? 4 : 2);
		if (roll < 35 && distance <= 10.0) {
			startAttack(ATTACK_SLAM);
		} else if (roll < 70 && canBarrage) {
			startAttack(ATTACK_BARRAGE);
		} else if (canSummon) {
			startAttack(ATTACK_SUMMON);
		} else if (distance <= 10.0) {
			startAttack(ATTACK_SLAM);
		} else {
			cooldown = 20;
		}
	}

	private void startAttack(int id) {
		currentAttack = id;
		attackTimer = 0;
		beams.clear();
		entityData.set(DATA_ATTACK, id);
		getNavigation().stop();
	}

	private void endAttack(int phase) {
		currentAttack = ATTACK_NONE;
		attackTimer = 0;
		entityData.set(DATA_ATTACK, ATTACK_NONE);
		cooldown = (phase == 1 ? 70 : phase == 2 ? 50 : 34) + random.nextInt(20);
	}

	private void runAttack(ServerLevel level, LivingEntity target, int phase) {
		attackTimer++;
		if (target != null) {
			getLookControl().setLookAt(target, 40.0F, 40.0F);
		}
		Vec3 motion = getDeltaMovement();
		setDeltaMovement(0.0, motion.y, 0.0);
		getNavigation().stop();

		switch (currentAttack) {
			case ATTACK_SLAM -> runSlam(level, phase);
			case ATTACK_BARRAGE -> runBarrage(level, target, phase);
			case ATTACK_SUMMON -> runSummon(level, phase);
			case ATTACK_ROAR -> runRoar(level, phase);
			default -> endAttack(phase);
		}
	}

	// ---- Abilities --------------------------------------------------------------------------------------

	/** Grave Slam: arms rise, the floor glows along the danger radius, then everything on the ground takes damage. Jump to avoid it. */
	private void runSlam(ServerLevel level, int phase) {
		double radius = phase == 3 ? 8.0 : 6.0;
		if (attackTimer == 1) {
			playSound(level, SoundEvents.RAVAGER_ROAR, 1.5F, 0.6F);
		}
		if (attackTimer < SLAM_IMPACT && attackTimer % 3 == 0) {
			ring(level, radius, ParticleTypes.SOUL_FIRE_FLAME, 28);
		}
		if (attackTimer == SLAM_IMPACT) {
			pulse(level, radius, scaled(10.0F + 3.0F * phase), 1.1, true);
			ring(level, radius * 0.5, ParticleTypes.POOF, 14);
			ring(level, radius, ParticleTypes.POOF, 28);
			level.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.3, getZ(), 1, 0.0, 0.0, 0.0, 0.0);
			playSound(level, SoundEvents.ANVIL_LAND, 2.0F, 0.6F);
		}
		if (attackTimer >= SLAM_TOTAL) {
			endAttack(phase);
		}
	}

	/** Wraith Barrage: beams are drawn first (wind-up), then fired along exactly those lines. Sidestep them. */
	private void runBarrage(ServerLevel level, LivingEntity target, int phase) {
		if (attackTimer == 1) {
			Vec3 base = target != null ? target.position().subtract(position()) : calculateViewVector(0.0F, getYRot());
			base = new Vec3(base.x, 0.0, base.z);
			base = base.lengthSqr() < 1.0E-4 ? new Vec3(0.0, 0.0, 1.0) : base.normalize();
			int[] angles = phase == 3 ? new int[]{-45, -30, -15, 0, 15, 30, 45} : new int[]{-30, -15, 0, 15, 30};
			for (int angle : angles) {
				beams.add(base.yRot((float) Math.toRadians(angle)));
			}
			playSound(level, SoundEvents.ENDER_DRAGON_GROWL, 1.5F, 1.3F);
		}
		Vec3 origin = new Vec3(getX(), getY() + 1.0, getZ());
		if (attackTimer < BARRAGE_FIRE && attackTimer % 2 == 0) {
			for (Vec3 direction : beams) {
				drawBeam(level, origin, direction, ParticleTypes.SOUL_FIRE_FLAME, 1.4);
			}
		}
		if (attackTimer == BARRAGE_FIRE) {
			Set<LivingEntity> alreadyHit = new HashSet<>();
			for (Vec3 direction : beams) {
				Vec3 end = origin.add(direction.scale(BEAM_LENGTH));
				for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class, new AABB(origin, end).inflate(1.5), this::isValidTarget)) {
					if (!alreadyHit.contains(victim) && victim.getBoundingBox().inflate(0.5).clip(origin, end).isPresent()) {
						alreadyHit.add(victim);
						victim.hurtServer(level, level.damageSources().magic(), scaled(7.0F + 1.5F * phase));
						victim.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 40, 1));
					}
				}
				drawBeam(level, origin, direction, ParticleTypes.SONIC_BOOM, 3.0);
			}
			playSound(level, SoundEvents.WARDEN_SONIC_BOOM, 2.0F, 1.0F);
		}
		if (attackTimer >= BARRAGE_TOTAL) {
			endAttack(phase);
		}
	}

	/** Call of the Fallen: after a channel, skeleton guards claw out of the floor (never more than four alive). */
	private void runSummon(ServerLevel level, int phase) {
		if (attackTimer == 1) {
			playSound(level, SoundEvents.EVOKER_PREPARE_SUMMON, 2.0F, 0.6F);
		}
		if (attackTimer % 4 == 0 && attackTimer < SUMMON_SPAWN) {
			ring(level, 3.0, ParticleTypes.SOUL, 10);
		}
		if (attackTimer == SUMMON_SPAWN) {
			spawnGuards(level, phase);
		}
		if (attackTimer >= SUMMON_TOTAL) {
			endAttack(phase);
		}
	}

	/** Phase change roar: the boss is invulnerable and shoves everyone away, giving players a moment to reset. */
	private void runRoar(ServerLevel level, int phase) {
		if (attackTimer == 1) {
			setInvulnerable(true);
			playSound(level, SoundEvents.WARDEN_ROAR, 3.0F, 0.6F);
		}
		if (attackTimer % 4 == 0 && attackTimer < ROAR_EFFECT) {
			ring(level, attackTimer * 0.3, ParticleTypes.SOUL_FIRE_FLAME, 20);
		}
		if (attackTimer == ROAR_EFFECT) {
			pulse(level, 10.0, 0.0F, 1.7, false);
			ring(level, 10.0, ParticleTypes.POOF, 36);
		}
		if (attackTimer >= ROAR_TOTAL) {
			setInvulnerable(false);
			endAttack(phase);
		}
	}

	private void spawnGuards(ServerLevel level, int phase) {
		int wanted = phase == 3 ? 3 : 2;
		int room = 4 - countGuards(level);
		int toSpawn = Math.min(wanted, room);
		int spawned = 0;
		for (int tries = 0; spawned < toSpawn && tries < 24; tries++) {
			double angle = random.nextDouble() * Math.PI * 2.0;
			double radius = 3.5 + random.nextDouble() * 2.5;
			double x = getX() + Math.cos(angle) * radius;
			double z = getZ() + Math.sin(angle) * radius;
			Mob guard = EntityTypes.SKELETON.create(level, EntitySpawnReason.MOB_SUMMONED);
			if (guard == null) {
				return;
			}
			guard.setPos(x, getY(), z);
			if (!level.noCollision(guard)) {
				continue;
			}
			guard.addTag(GUARD_TAG);
			guard.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
			guard.setPersistenceRequired();
			LivingEntity target = getTarget();
			if (target != null) {
				guard.setTarget(target);
			}
			level.addFreshEntity(guard);
			level.sendParticles(ParticleTypes.SOUL, x, getY() + 1.0, z, 10, 0.3, 0.5, 0.3, 0.03);
			spawned++;
		}
		playSound(level, SoundEvents.EVOKER_CAST_SPELL, 2.0F, 0.7F);
	}

	private int countGuards(ServerLevel level) {
		return level.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(48.0), e -> e.isAlive() && e.getTags().contains(GUARD_TAG)).size();
	}

	// ---- Helpers ----------------------------------------------------------------------------------------

	private boolean isValidTarget(LivingEntity entity) {
		return entity != this && entity.isAlive() && !entity.isSpectator()
				&& !(entity instanceof HollowRegentEntity) && !entity.getTags().contains(GUARD_TAG);
	}

	private float scaled(float base) {
		return (float) (base * ReimaginedConfig.get().bossDamageMultiplier);
	}

	/** Damages and shoves every valid target within {@code radius} blocks. */
	private void pulse(ServerLevel level, double radius, float damage, double knockback, boolean groundedOnly) {
		AABB area = getBoundingBox().inflate(radius, 3.0, radius);
		for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, area, this::isValidTarget)) {
			double dx = entity.getX() - getX();
			double dz = entity.getZ() - getZ();
			if (dx * dx + dz * dz > radius * radius) {
				continue;
			}
			if (groundedOnly && !entity.onGround()) {
				continue;
			}
			if (damage > 0.0F) {
				entity.hurtServer(level, level.damageSources().mobAttack(this), damage);
			}
			entity.knockback(knockback, getX() - entity.getX(), getZ() - entity.getZ());
			entity.push(0.0, 0.4, 0.0);
		}
	}

	private void ring(ServerLevel level, double radius, ParticleOptions particle, int count) {
		for (int i = 0; i < count; i++) {
			double angle = (Math.PI * 2.0) * i / count;
			level.sendParticles(particle, getX() + Math.cos(angle) * radius, getY() + 0.1, getZ() + Math.sin(angle) * radius, 1, 0.0, 0.05, 0.0, 0.0);
		}
	}

	private void drawBeam(ServerLevel level, Vec3 origin, Vec3 direction, ParticleOptions particle, double step) {
		for (double d = 1.5; d < BEAM_LENGTH; d += step) {
			level.sendParticles(particle, origin.x + direction.x * d, origin.y, origin.z + direction.z * d, 1, 0.0, 0.0, 0.0, 0.0);
		}
	}

	private void playSound(ServerLevel level, SoundEvent sound, float volume, float pitch) {
		level.playSound(null, getX(), getY(), getZ(), sound, SoundSource.HOSTILE, volume, pitch);
	}

	// ---- Damage, death, persistence ---------------------------------------------------------------------

	@Override
	public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
		return super.hurtServer(level, source, Math.min(amount, (float) ReimaginedConfig.get().bossMaxDamagePerHit));
	}

	@Override
	public void die(DamageSource source) {
		super.die(source);
		if (level() instanceof ServerLevel level) {
			for (Mob guard : level.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(64.0), e -> e.getTags().contains(GUARD_TAG))) {
				guard.discard();
			}
			ExperienceOrb.award(level, position(), 800);
			level.getServer().getPlayerList().broadcastSystemMessage(Component.translatable("message.reimagined.regent_slain"), false);
		}
	}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	// Intentionally not annotated: keeps the boss alive in Peaceful (it simply will not attack there).
	protected boolean shouldDespawnInPeaceful() {
		return false;
	}

	@Override
	protected void addAdditionalSaveData(ValueOutput output) {
		super.addAdditionalSaveData(output);
		output.putInt("reimagined_state", getState());
	}

	@Override
	protected void readAdditionalSaveData(ValueInput input) {
		super.readAdditionalSaveData(input);
		int state = Mth.clamp(input.getInt("reimagined_state").orElse(STATE_DORMANT), STATE_DORMANT, STATE_FIGHT);
		entityData.set(DATA_STATE, state);
		applyStateFlags(state);
		lastPhase = getPhase();
	}

	// ---- Sounds -----------------------------------------------------------------------------------------

	@Override
	protected SoundEvent getAmbientSound() {
		return SoundEvents.WITHER_SKELETON_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.WITHER_SKELETON_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.WITHER_SKELETON_DEATH;
	}
}
