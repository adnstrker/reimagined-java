package dev.reimagined.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import net.fabricmc.loader.api.FabricLoader;

import dev.reimagined.ReimaginedMod;

/**
 * Server/common configuration, stored in {@code config/reimagined.json}.
 * Values are read once at start-up; edit the file and restart to apply.
 */
public final class ReimaginedConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	/** Multiplies the Hollow Regent's maximum health. */
	public double bossHealthMultiplier = 1.0;
	/** Multiplies all damage dealt by the Hollow Regent's abilities and melee attacks. */
	public double bossDamageMultiplier = 1.0;
	/** A single hit can never remove more than this much health from the boss (anti-burst safeguard). */
	public double bossMaxDamagePerHit = 40.0;
	/** Master switch for the Gravesteel armour set bonuses. */
	public boolean armorSetBonuses = true;
	/** Allows the Regent's Vault to generate in newly created chunks. */
	public boolean generateVaults = true;

	private static ReimaginedConfig instance = new ReimaginedConfig();

	public static ReimaginedConfig get() {
		return instance;
	}

	public static void load() {
		Path file = FabricLoader.getInstance().getConfigDir().resolve("reimagined.json");
		try {
			if (Files.exists(file)) {
				ReimaginedConfig loaded = GSON.fromJson(Files.readString(file), ReimaginedConfig.class);
				if (loaded != null) {
					instance = loaded;
				}
			}
			Files.writeString(file, GSON.toJson(instance));
		} catch (IOException | RuntimeException e) {
			ReimaginedMod.LOGGER.error("Could not read or write reimagined.json, using defaults", e);
		}
	}

	private ReimaginedConfig() {
	}
}
