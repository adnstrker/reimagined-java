package dev.reimagined;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.minecraft.resources.Identifier;

import net.fabricmc.api.ModInitializer;

import dev.reimagined.combat.ArmorSetBonuses;
import dev.reimagined.combat.CombatEvents;
import dev.reimagined.config.ReimaginedConfig;
import dev.reimagined.entity.ModEntities;
import dev.reimagined.item.ModItems;
import dev.reimagined.network.ModNetworking;
import dev.reimagined.world.ModWorldgen;

/**
 * Reimagined: common entrypoint.
 *
 * <p>Initialisation order matters: entities first (the sigil and vault feature refer to the boss type),
 * then items, world generation, networking and finally the gameplay event hooks.
 */
public class ReimaginedMod implements ModInitializer {
	public static final String MOD_ID = "reimagined";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ReimaginedConfig.load();
		ModEntities.initialize();
		ModItems.initialize();
		ModWorldgen.initialize();
		ModNetworking.initialize();
		CombatEvents.initialize();
		ArmorSetBonuses.initialize();
		LOGGER.info("Reimagined loaded: the Hollow Regent stirs beneath the world.");
	}
}
