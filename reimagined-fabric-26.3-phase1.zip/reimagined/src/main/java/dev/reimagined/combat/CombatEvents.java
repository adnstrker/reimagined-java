package dev.reimagined.combat;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

import dev.reimagined.item.ModItems;

/**
 * Weapon abilities that trigger on melee hits. They are implemented through Fabric's
 * {@code AFTER_DAMAGE} event rather than item subclasses so that every weapon stays a plain vanilla item
 * type (swords stay swords, spears stay spears) and remain compatible with other mods' tooling.
 *
 * <ul>
 *   <li><b>Gravesteel Sword, Grave Wave:</b> every fourth hit releases a wave that damages nearby enemies.</li>
 *   <li><b>Gravesteel Spear, Hamstring:</b> hits briefly slow the target.</li>
 * </ul>
 */
public final class CombatEvents {
	private static final Map<UUID, Integer> SWORD_HITS = new HashMap<>();
	/** Guards against abilities triggering themselves through the damage they deal. */
	private static boolean inAbility = false;

	private CombatEvents() {
	}

	/** Runs {@code action} while melee-triggered abilities are suppressed. */
	public static void runAbility(Runnable action) {
		boolean previous = inAbility;
		inAbility = true;
		try {
			action.run();
		} finally {
			inAbility = previous;
		}
	}

	public static void initialize() {
		ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamageTaken, damageTaken, blocked) -> {
			if (inAbility || blocked || damageTaken <= 0.0F) {
				return;
			}
			if (!(source.getEntity() instanceof ServerPlayer player) || source.getDirectEntity() != player) {
				return;
			}
			if (!(entity.level() instanceof ServerLevel level)) {
				return;
			}
			ItemStack weapon = player.getMainHandItem();
			if (weapon.is(ModItems.GRAVESTEEL_SWORD)) {
				graveWave(level, player, entity, damageTaken);
			} else if (weapon.is(ModItems.GRAVESTEEL_SPEAR)) {
				entity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 40, 0));
			}
		});
	}

	private static void graveWave(ServerLevel level, ServerPlayer player, LivingEntity target, float damageTaken) {
		int hits = SWORD_HITS.merge(player.getUUID(), 1, Integer::sum);
		if (hits < 4) {
			return;
		}
		SWORD_HITS.put(player.getUUID(), 0);

		float waveDamage = Math.max(2.0F, damageTaken * 0.5F);
		runAbility(() -> {
			for (LivingEntity other : level.getEntitiesOfClass(LivingEntity.class, target.getBoundingBox().inflate(3.0, 1.0, 3.0),
					e -> e != player && e != target && e.isAlive() && !e.isAlliedTo(player))) {
				other.hurtServer(level, level.damageSources().playerAttack(player), waveDamage);
			}
		});
		level.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), target.getY() + 1.0, target.getZ(), 3, 1.2, 0.2, 1.2, 0.0);
		level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, target.getX(), target.getY() + 0.8, target.getZ(), 18, 1.0, 0.3, 1.0, 0.04);
		level.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0F, 0.7F);
	}
}
