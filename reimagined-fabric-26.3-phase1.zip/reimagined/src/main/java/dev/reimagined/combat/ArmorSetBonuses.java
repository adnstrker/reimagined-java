package dev.reimagined.combat;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import dev.reimagined.config.ReimaginedConfig;
import dev.reimagined.item.ModItems;

/**
 * Gravesteel set bonuses, evaluated once a second per player.
 *
 * <ul>
 *   <li><b>2+ pieces, Vault Walker:</b> Haste I while below Y=40 (a mining perk for the underground).</li>
 *   <li><b>4 pieces, Gravebound Resolve:</b> dropping to 30% health grants Absorption II and Resistance I
 *       for a few seconds. 45 second cooldown.</li>
 * </ul>
 */
public final class ArmorSetBonuses {
	private static final int RESOLVE_COOLDOWN_TICKS = 900;
	private static final Map<UUID, Integer> LAST_RESOLVE = new HashMap<>();

	private ArmorSetBonuses() {
	}

	public static int countPieces(ServerPlayer player) {
		int count = 0;
		if (player.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.GRAVESTEEL_HELMET)) {
			count++;
		}
		if (player.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.GRAVESTEEL_CHESTPLATE)) {
			count++;
		}
		if (player.getItemBySlot(EquipmentSlot.LEGS).is(ModItems.GRAVESTEEL_LEGGINGS)) {
			count++;
		}
		if (player.getItemBySlot(EquipmentSlot.FEET).is(ModItems.GRAVESTEEL_BOOTS)) {
			count++;
		}
		return count;
	}

	public static void initialize() {
		ServerTickEvents.END_SERVER_TICK.register(ArmorSetBonuses::tick);
	}

	private static void tick(MinecraftServer server) {
		if (!ReimaginedConfig.get().armorSetBonuses || server.getTickCount() % 20 != 0) {
			return;
		}
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			int pieces = countPieces(player);
			if (pieces < 2) {
				continue;
			}
			if (player.getY() < 40.0) {
				player.addEffect(new MobEffectInstance(MobEffects.HASTE, 60, 0, true, false, true));
			}
			if (pieces == 4) {
				resolve(server, player);
			}
		}
	}

	private static void resolve(MinecraftServer server, ServerPlayer player) {
		Integer last = LAST_RESOLVE.get(player.getUUID());
		if (last != null && server.getTickCount() - last < RESOLVE_COOLDOWN_TICKS) {
			return;
		}
		if (player.getHealth() > player.getMaxHealth() * 0.3F) {
			return;
		}
		LAST_RESOLVE.put(player.getUUID(), server.getTickCount());
		player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 1));
		player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 120, 0));
		player.displayClientMessage(Component.translatable("message.reimagined.resolve"), true);
		if (player.level() instanceof ServerLevel level) {
			level.sendParticles(ParticleTypes.SOUL, player.getX(), player.getY() + 1.0, player.getZ(), 20, 0.4, 0.8, 0.4, 0.05);
		}
	}
}
