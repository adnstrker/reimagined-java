package dev.reimagined.client.entity;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class HollowRegentRenderState extends LivingEntityRenderState {
	/** One of HollowRegentEntity.STATE_*. */
	public int stateId;
	/** Ticks (with partial tick) spent in the current state. */
	public float stateAge;
	/** One of HollowRegentEntity.ATTACK_*. */
	public int attackId;
	/** Ticks (with partial tick) since the current attack began. */
	public float attackAge;
	public int phase;
}
