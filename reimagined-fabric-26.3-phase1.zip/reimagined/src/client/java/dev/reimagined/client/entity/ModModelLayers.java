package dev.reimagined.client.entity;

import net.minecraft.client.model.geom.ModelLayerLocation;

import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;

import dev.reimagined.ReimaginedMod;

public final class ModModelLayers {
	public static final ModelLayerLocation HOLLOW_REGENT = new ModelLayerLocation(ReimaginedMod.id("hollow_regent"), "main");

	public static void registerModelLayers() {
		ModelLayerRegistry.registerModelLayer(HOLLOW_REGENT, HollowRegentModel::createBodyLayer);
	}

	private ModModelLayers() {
	}
}
