package dev.reimagined.client.hud;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

/**
 * In-game HUD settings (default key: H). Every element can be toggled, the info panel can be moved
 * between the four corners and the accent colour can be cycled. Changes apply live and are saved on close.
 */
public class HudSettingsScreen extends Screen {
	private static final String[] CORNERS = {"Top left", "Top right", "Bottom left", "Bottom right"};
	private static final String[] ACCENTS = {"Soul cyan", "Royal gold", "Crimson", "Violet"};

	private final Screen parent;

	public HudSettingsScreen(Screen parent) {
		super(Component.literal("Reimagined HUD"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		HudConfig config = HudConfig.get();
		int left = this.width / 2 - 154;
		int right = this.width / 2 + 4;
		int y = 44;

		toggle(left, y, "Custom status bars", () -> config.statusBars, v -> config.statusBars = v);
		toggle(right, y, "Boss bar", () -> config.bossBar, v -> config.bossBar = v);
		y += 24;
		toggle(left, y, "Weapon info", () -> config.weaponInfo, v -> config.weaponInfo = v);
		toggle(right, y, "Effect timers", () -> config.effectTimers, v -> config.effectTimers = v);
		y += 24;
		toggle(left, y, "Coordinates", () -> config.coordinates, v -> config.coordinates = v);
		toggle(right, y, "Biome", () -> config.biome, v -> config.biome = v);
		y += 24;
		toggle(left, y, "Compass", () -> config.compass, v -> config.compass = v);
		cycle(right, y, "Info corner", CORNERS, () -> config.corner, v -> config.corner = v);
		y += 24;
		cycle(left, y, "Accent colour", ACCENTS, () -> config.accent, v -> config.accent = v);

		this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, button -> this.onClose())
				.bounds(this.width / 2 - 100, this.height - 32, 200, 20)
				.build());
	}

	private void toggle(int x, int y, String label, BooleanSupplier getter, Consumer<Boolean> setter) {
		Button button = Button.builder(toggleText(label, getter.getAsBoolean()), b -> {
			boolean next = !getter.getAsBoolean();
			setter.accept(next);
			b.setMessage(toggleText(label, next));
		}).bounds(x, y, 150, 20).build();
		this.addRenderableWidget(button);
	}

	private void cycle(int x, int y, String label, String[] options, java.util.function.IntSupplier getter, java.util.function.IntConsumer setter) {
		Button button = Button.builder(Component.literal(label + ": " + options[getter.getAsInt() % options.length]), b -> {
			int next = (getter.getAsInt() + 1) % options.length;
			setter.accept(next);
			b.setMessage(Component.literal(label + ": " + options[next]));
		}).bounds(x, y, 150, 20).build();
		this.addRenderableWidget(button);
	}

	private static Component toggleText(String label, boolean on) {
		return Component.literal(label + ": " + (on ? "ON" : "OFF"));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		graphics.text(this.font, this.title.getString(), this.width / 2 - this.font.width(this.title.getString()) / 2, 20, 0xFFFFFFFF, true);
		String hint = "Changes apply instantly. Press H in game to reopen.";
		graphics.text(this.font, hint, this.width / 2 - this.font.width(hint) / 2, this.height - 46, 0xFFA0A4AA, true);
	}

	@Override
	public void onClose() {
		HudConfig.save();
		this.minecraft.gui.setScreen(this.parent);
	}
}
