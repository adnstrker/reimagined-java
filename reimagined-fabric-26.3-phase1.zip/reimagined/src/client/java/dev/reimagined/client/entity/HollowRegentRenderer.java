package dev.reimagined.client.entity;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

import dev.reimagined.ReimaginedMod;
import dev.reimagined.entity.HollowRegentEntity;

public class HollowRegentRenderer extends MobRenderer<HollowRegentEntity, HollowRegentRenderState, HollowRegentModel> {
	private static final Identifier TEXTURE = ReimaginedMod.id("textures/entity/hollow_regent.png");

	public HollowRegentRenderer(EntityRendererProvider.Context context) {
		super(context, new HollowRegentModel(context.bakeLayer(ModModelLayers.HOLLOW_REGENT)), 1.3F);
	}

	@Override
	public HollowRegentRenderState createRenderState() {
		return new HollowRegentRenderState();
	}

	@Override
	public void extractRenderState(HollowRegentEntity entity, HollowRegentRenderState state, float tickProgress) {
		super.extractRenderState(entity, state, tickProgress);
		state.stateId = entity.getState();
		state.stateAge = state.ageInTicks - entity.stateStartTick;
		state.attackId = entity.getAttackId();
		state.attackAge = state.ageInTicks - entity.attackStartTick;
		state.phase = entity.getPhase();
	}

	@Override
	public Identifier getTextureLocation(HollowRegentRenderState state) {
		return TEXTURE;
	}
}
