package dev.reimagined.client.hud;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.biome.Biome;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;

import dev.reimagined.ReimaginedMod;

/**
 * Reimagined HUD. Everything is drawn with flat, hard-edged rectangles and vanilla text so it stays in
 * the same pixel-art language as the game: no gradients, no blur, a limited colour ramp per element.
 *
 * <p>Replaced vanilla elements (each can be switched off, which falls back to the vanilla version):
 * health, hunger, armor, experience level and mob effects. Added elements: boss bar, weapon info,
 * info panel (coordinates, biome) and compass.
 */
public final class ReimaginedHud {
	private static final int FRAME = 0xFF101216;
	private static final int PANEL = 0xB0000000;
	private static final int WHITE = 0xFFFFFFFF;
	private static final int GRAY = 0xFFA0A4AA;

	private ReimaginedHud() {
	}

	private static HudConfig cfg() {
		return HudConfig.get();
	}

	public static void register() {
		HudElementRegistry.replaceElement(VanillaHudElements.HEALTH_BAR, original -> (graphics, tracker) -> {
			if (cfg().statusBars) {
				extractHealth(graphics);
			} else {
				original.extractRenderState(graphics, tracker);
			}
		});
		HudElementRegistry.replaceElement(VanillaHudElements.FOOD_BAR, original -> (graphics, tracker) -> {
			if (cfg().statusBars) {
				extractFood(graphics);
			} else {
				original.extractRenderState(graphics, tracker);
			}
		});
		HudElementRegistry.replaceElement(VanillaHudElements.ARMOR_BAR, original -> (graphics, tracker) -> {
			if (cfg().statusBars) {
				extractArmor(graphics);
			} else {
				original.extractRenderState(graphics, tracker);
			}
		});
		HudElementRegistry.replaceElement(VanillaHudElements.EXPERIENCE_LEVEL, original -> (graphics, tracker) -> {
			if (cfg().statusBars) {
				extractLevel(graphics);
			} else {
				original.extractRenderState(graphics, tracker);
			}
		});
		HudElementRegistry.replaceElement(VanillaHudElements.MOB_EFFECTS, original -> (graphics, tracker) -> {
			if (cfg().effectTimers) {
				extractEffects(graphics);
			} else {
				original.extractRenderState(graphics, tracker);
			}
		});

		HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, ReimaginedMod.id("boss_bar"), ReimaginedHud::extractBossBars);
		HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, ReimaginedMod.id("weapon_info"), ReimaginedHud::extractWeaponInfo);
		HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, ReimaginedMod.id("info_panel"), ReimaginedHud::extractInfoPanel);
		HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, ReimaginedMod.id("compass"), ReimaginedHud::extractCompass);
	}

	// ---- Helpers ----------------------------------------------------------------------------------------

	private static LocalPlayer survivalPlayer() {
		LocalPlayer player = Minecraft.getInstance().player;
		if (player == null || player.isCreative() || player.isSpectator()) {
			return null;
		}
		return player;
	}

	/** Framed bar background: dark outline, then a dark inner well. Returns nothing; inner area is (x+1, y+1) to (x+w-1, y+h-1). */
	private static void frame(GuiGraphicsExtractor g, int x, int y, int w, int h, int well) {
		g.fill(x, y, x + w, y + h, FRAME);
		g.fill(x + 1, y + 1, x + w - 1, y + h - 1, well);
	}

	/** A flat two-tone fill: a lighter top half over a darker bottom half. */
	private static void fillTwoTone(GuiGraphicsExtractor g, int x, int y, int w, int h, int top, int bottom) {
		if (w <= 0) {
			return;
		}
		int split = y + h / 2;
		g.fill(x, y, x + w, split, top);
		g.fill(x, split, x + w, y + h, bottom);
	}

	private static void ticks(GuiGraphicsExtractor g, int x, int y, int innerW, int h, int count, int color) {
		for (int i = 1; i < count; i++) {
			int tx = x + innerW * i / count;
			g.fill(tx, y, tx + 1, y + h, color);
		}
	}

	// ---- Status bars ------------------------------------------------------------------------------------

	private static void extractHealth(GuiGraphicsExtractor g) {
		LocalPlayer player = survivalPlayer();
		if (player == null) {
			return;
		}
		Font font = Minecraft.getInstance().font;
		int x = g.guiWidth() / 2 - 91;
		int y = g.guiHeight() - 40;
		int w = 81;
		int h = 10;
		float health = player.getHealth();
		float max = Math.max(1.0F, player.getMaxHealth());
		float absorption = player.getAbsorptionAmount();

		boolean poisoned = player.hasEffect(MobEffects.POISON);
		boolean withered = player.hasEffect(MobEffects.WITHER);
		int top = withered ? 0xFF5A4A4A : poisoned ? 0xFF9AB43C : 0xFFE0555E;
		int bottom = withered ? 0xFF2E2424 : poisoned ? 0xFF6A8426 : 0xFF9A2530;

		boolean low = health <= max * 0.3F;
		if (low && (player.tickCount / 6) % 2 == 0) {
			g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFFE0524A);
		}
		frame(g, x, y, w, h, 0xFF2A1A1C);
		int innerW = w - 2;
		int fillW = Mth.ceil(innerW * Mth.clamp(health / max, 0.0F, 1.0F));
		fillTwoTone(g, x + 1, y + 1, fillW, h - 2, top, bottom);
		if (absorption > 0.0F) {
			int absW = Math.min(innerW - fillW, Mth.ceil(innerW * absorption / max));
			if (absW > 0) {
				fillTwoTone(g, x + 1 + fillW, y + 1, absW, h - 2, 0xFFF2D25A, 0xFFC09A2A);
			}
		}
		ticks(g, x + 1, y + 1, innerW, h - 2, Mth.clamp(Mth.ceil(max / 2.0F), 1, 20), 0x66000000);
		String text = Mth.ceil(health) + (absorption > 0.0F ? "+" + Mth.ceil(absorption) : "");
		g.text(font, text, x + 4, y + 1, WHITE, true);
	}

	private static void extractFood(GuiGraphicsExtractor g) {
		LocalPlayer player = survivalPlayer();
		if (player == null) {
			return;
		}
		Font font = Minecraft.getInstance().font;
		int x = g.guiWidth() / 2 + 10;
		int y = g.guiHeight() - 40;
		int w = 81;
		int h = 10;
		int food = player.getFoodData().getFoodLevel();
		float saturation = player.getFoodData().getSaturationLevel();
		boolean hungry = player.hasEffect(MobEffects.HUNGER);

		frame(g, x, y, w, h, 0xFF2A2218);
		int innerW = w - 2;
		int fillW = Mth.ceil(innerW * Mth.clamp(food / 20.0F, 0.0F, 1.0F));
		int top = hungry ? 0xFF9AA060 : 0xFFE8A84A;
		int bottom = hungry ? 0xFF6E7440 : 0xFFA86A1E;
		// Hunger drains from the left edge, like the vanilla row.
		fillTwoTone(g, x + 1 + (innerW - fillW), y + 1, fillW, h - 2, top, bottom);
		if (saturation > 0.0F) {
			int satW = Mth.ceil(innerW * Mth.clamp(saturation / 20.0F, 0.0F, 1.0F));
			g.fill(x + 1 + (innerW - satW), y + 1, x + 1 + innerW, y + 2, 0xFFFFF0B0);
		}
		ticks(g, x + 1, y + 1, innerW, h - 2, 10, 0x66000000);
		String text = Integer.toString(food);
		g.text(font, text, x + w - 4 - font.width(text), y + 1, WHITE, true);
	}

	private static void extractArmor(GuiGraphicsExtractor g) {
		LocalPlayer player = survivalPlayer();
		if (player == null) {
			return;
		}
		int armor = player.getArmorValue();
		if (armor <= 0) {
			return;
		}
		Font font = Minecraft.getInstance().font;
		int x = g.guiWidth() / 2 - 91;
		int y = g.guiHeight() - 50;
		for (int i = 0; i < 10; i++) {
			int segment = x + i * 8;
			int points = Mth.clamp(armor - i * 2, 0, 2);
			g.fill(segment, y, segment + 7, y + 4, FRAME);
			g.fill(segment + 1, y + 1, segment + 6, y + 3, 0xFF2E3238);
			if (points > 0) {
				int filled = points == 2 ? 5 : 3;
				g.fill(segment + 1, y + 1, segment + 1 + filled, y + 2, 0xFFD6DEE8);
				g.fill(segment + 1, y + 2, segment + 1 + filled, y + 3, 0xFF8E9AAA);
			}
		}
		if (armor > 20) {
			g.text(font, "+" + (armor - 20), x + 82, y - 2, 0xFFD6DEE8, true);
		}
	}

	private static void extractLevel(GuiGraphicsExtractor g) {
		LocalPlayer player = survivalPlayer();
		if (player == null || player.experienceLevel <= 0) {
			return;
		}
		Font font = Minecraft.getInstance().font;
		String text = Integer.toString(player.experienceLevel);
		int width = font.width(text);
		int cx = g.guiWidth() / 2;
		int y = g.guiHeight() - 36;
		g.fill(cx - width / 2 - 3, y - 1, cx + (width + 1) / 2 + 3, y + 9, FRAME);
		g.fill(cx - width / 2 - 2, y, cx + (width + 1) / 2 + 2, y + 8, 0xFF1C2418);
		g.text(font, text, cx - width / 2, y, cfg().accentColor(), true);
	}

	// ---- Boss bar ---------------------------------------------------------------------------------------

	/** Number of custom boss bars currently on screen (used to push the compass down). */
	private static int activeBossBars() {
		Minecraft minecraft = Minecraft.getInstance();
		if (minecraft.level == null || !cfg().bossBar) {
			return 0;
		}
		int count = 0;
		for (var entry : BossBarTracker.prune(minecraft.level.getGameTime()).entrySet()) {
			if (entry.getValue().state() >= 1 && minecraft.level.getEntity(entry.getKey()) != null) {
				count++;
			}
		}
		return count;
	}

	private static void extractBossBars(GuiGraphicsExtractor g, DeltaTracker tracker) {
		Minecraft minecraft = Minecraft.getInstance();
		if (minecraft.level == null || !cfg().bossBar) {
			return;
		}
		Font font = minecraft.font;
		int width = 230;
		int x = (g.guiWidth() - width) / 2;
		int row = 0;
		for (var entry : BossBarTracker.prune(minecraft.level.getGameTime()).entrySet()) {
			BossBarTracker.Entry boss = entry.getValue();
			Entity entity = minecraft.level.getEntity(entry.getKey());
			if (entity == null || boss.state() < 1) {
				continue;
			}
			int y = 18 + row * 34;
			String name = entity.getDisplayName().getString();
			g.text(font, name, (g.guiWidth() - font.width(name)) / 2, y - 11, WHITE, true);

			int accent = cfg().accentColor();
			int accentDark = cfg().accentDark();
			// Frame: dark outer, accent border, dark well. Gold studs on the outer corners.
			g.fill(x - 3, y - 3, x + width + 3, y + 13, FRAME);
			g.fill(x - 2, y - 2, x + width + 2, y + 12, accentDark);
			g.fill(x - 1, y - 1, x + width + 1, y + 11, FRAME);
			g.fill(x, y, x + width, y + 10, 0xFF1A1114);
			int stud = 0xFFE6C868;
			g.fill(x - 4, y - 4, x - 1, y - 1, stud);
			g.fill(x + width + 1, y - 4, x + width + 4, y - 1, stud);
			g.fill(x - 4, y + 11, x - 1, y + 14, stud);
			g.fill(x + width + 1, y + 11, x + width + 4, y + 14, stud);

			float fraction = Mth.clamp(boss.health() / Math.max(1.0F, boss.maxHealth()), 0.0F, 1.0F);
			boolean awakening = boss.state() == 1;
			int fillW = Mth.ceil(width * (awakening ? 1.0F : fraction));
			if (awakening) {
				fillTwoTone(g, x, y, fillW, 10, 0xFF6E7078, 0xFF50525A);
			} else {
				fillTwoTone(g, x, y, fillW, 10, 0xFFD8434C, 0xFF8C1F2B);
			}
			// Phase markers at 66% and 33%.
			for (int marker = 1; marker <= 2; marker++) {
				int mx = x + width * marker / 3;
				g.fill(mx - 1, y, mx + 1, y + 10, FRAME);
				g.fill(mx - 1, y - 3, mx + 1, y - 1, accent);
				g.fill(mx - 1, y + 11, mx + 1, y + 13, accent);
			}

			String phase = awakening ? "..." : "Phase " + toRoman(boss.phase());
			g.text(font, phase, x, y + 16, accent, true);
			String percent = awakening ? "" : Mth.ceil(fraction * 100.0F) + "%";
			g.text(font, percent, x + width - font.width(percent), y + 16, GRAY, true);
			row++;
			if (row >= 2) {
				break;
			}
		}
	}

	// ---- Weapon info ------------------------------------------------------------------------------------

	private static void extractWeaponInfo(GuiGraphicsExtractor g, DeltaTracker tracker) {
		if (!cfg().weaponInfo) {
			return;
		}
		Minecraft minecraft = Minecraft.getInstance();
		LocalPlayer player = minecraft.player;
		if (player == null || player.isSpectator()) {
			return;
		}
		Font font = minecraft.font;
		int cx = g.guiWidth() / 2;
		int cy = g.guiHeight() / 2;
		int barW = 32;
		int x = cx - barW / 2;

		float strength = player.getAttackStrengthScale(tracker.getGameTimeDeltaPartialTick(false));
		int y = cy + 11;
		if (strength < 1.0F) {
			g.fill(x - 1, y - 1, x + barW + 1, y + 3, FRAME);
			g.fill(x, y, x + barW, y + 2, 0xFF2A2E34);
			g.fill(x, y, x + Mth.ceil(barW * strength), y + 2, cfg().accentColor());
			y += 5;
		}

		ItemStack held = player.getMainHandItem();
		if (held.isDamageableItem() && held.getDamageValue() > 0) {
			int max = held.getMaxDamage();
			int left = max - held.getDamageValue();
			float fraction = Mth.clamp((float) left / max, 0.0F, 1.0F);
			int color = fraction > 0.5F ? 0xFF6FD25A : fraction > 0.2F ? 0xFFE8C040 : 0xFFE0524A;
			boolean flash = fraction <= 0.1F && (player.tickCount / 5) % 2 == 0;
			g.fill(x - 1, y - 1, x + barW + 1, y + 3, flash ? 0xFFE0524A : FRAME);
			g.fill(x, y, x + barW, y + 2, 0xFF2A2E34);
			g.fill(x, y, x + Mth.ceil(barW * fraction), y + 2, color);
			String text = Integer.toString(left);
			g.text(font, text, cx - font.width(text) / 2, y + 4, GRAY, true);
		}
	}

	// ---- Effects ----------------------------------------------------------------------------------------

	private static void extractEffects(GuiGraphicsExtractor g) {
		Minecraft minecraft = Minecraft.getInstance();
		LocalPlayer player = minecraft.player;
		if (player == null || player.getActiveEffects().isEmpty()) {
			return;
		}
		Font font = minecraft.font;
		int right = g.guiWidth() - 4;
		int y = 4;
		for (MobEffectInstance effect : player.getActiveEffects()) {
			Holder<MobEffect> holder = effect.getEffect();
			MobEffect type = holder.value();
			Identifier key = BuiltInRegistries.MOB_EFFECT.getKey(type);
			boolean beneficial = type.isBeneficial();

			int iconX = right - 18;
			g.fill(iconX - 1, y - 1, iconX + 19, y + 19, FRAME);
			g.fill(iconX, y, iconX + 18, y + 18, beneficial ? 0xFF1F2A1F : 0xFF2E1B1B);
			if (key != null) {
				Identifier sprite = Identifier.fromNamespaceAndPath(key.getNamespace(), "mob_effect/" + key.getPath());
				g.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, iconX, y, 18, 18);
			}

			String name = type.getDisplayName().getString() + (effect.getAmplifier() > 0 ? " " + toRoman(effect.getAmplifier() + 1) : "");
			String time = effect.isInfiniteDuration() ? "**:**" : formatTime(effect.getDuration());
			boolean expiring = !effect.isInfiniteDuration() && effect.getDuration() <= 200 && (player.tickCount / 5) % 2 == 0;
			g.text(font, name, iconX - 4 - font.width(name), y + 1, beneficial ? 0xFFB8F0A8 : 0xFFF0A8A8, true);
			g.text(font, time, iconX - 4 - font.width(time), y + 10, expiring ? 0xFFE0524A : GRAY, true);
			y += 22;
		}
	}

	// ---- Info panel and compass -------------------------------------------------------------------------

	private static void extractInfoPanel(GuiGraphicsExtractor g, DeltaTracker tracker) {
		HudConfig config = cfg();
		if (!config.coordinates && !config.biome) {
			return;
		}
		Minecraft minecraft = Minecraft.getInstance();
		LocalPlayer player = minecraft.player;
		if (player == null || minecraft.level == null) {
			return;
		}
		Font font = minecraft.font;
		java.util.List<String> lines = new java.util.ArrayList<>();
		if (config.coordinates) {
			lines.add("XYZ " + player.getBlockX() + " " + player.getBlockY() + " " + player.getBlockZ());
		}
		if (config.biome) {
			lines.add(biomeName(minecraft.level.getBiome(player.blockPosition())));
		}
		int width = 0;
		for (String line : lines) {
			width = Math.max(width, font.width(line));
		}
		int boxW = width + 8;
		int boxH = lines.size() * 10 + 4;
		int x = (config.corner == 1 || config.corner == 3) ? g.guiWidth() - 4 - boxW : 4;
		int y = (config.corner >= 2) ? g.guiHeight() - 4 - boxH : 4;
		if (config.corner == 1 && config.effectTimers) {
			y += 26 * Math.max(1, player.getActiveEffects().size());
		}
		g.fill(x, y, x + boxW, y + boxH, PANEL);
		g.fill(x, y, x + 2, y + boxH, config.accentColor());
		for (int i = 0; i < lines.size(); i++) {
			g.text(font, lines.get(i), x + 6, y + 3 + i * 10, WHITE, true);
		}
	}

	private static String biomeName(Holder<Biome> biome) {
		String registered = biome.getRegisteredName();
		int colon = registered.indexOf(':');
		if (colon < 0) {
			return registered;
		}
		return Component.translatable("biome." + registered.substring(0, colon) + "." + registered.substring(colon + 1)).getString();
	}

	private static final String[] POINT_NAMES = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

	private static void extractCompass(GuiGraphicsExtractor g, DeltaTracker tracker) {
		if (!cfg().compass) {
			return;
		}
		Minecraft minecraft = Minecraft.getInstance();
		LocalPlayer player = minecraft.player;
		if (player == null) {
			return;
		}
		Font font = minecraft.font;
		int width = 150;
		int cx = g.guiWidth() / 2;
		int x = cx - width / 2;
		int y = 4 + activeBossBars() * 34 + (activeBossBars() > 0 ? 18 : 0);
		g.fill(x, y, x + width, y + 13, PANEL);
		g.fill(x, y + 12, x + width, y + 13, cfg().accentDark());

		float heading = Mth.wrapDegrees(player.getYRot() + 180.0F);
		float pixelsPerDegree = (width / 2.0F - 8.0F) / 80.0F;
		for (int angle = 0; angle < 360; angle += 15) {
			float diff = Mth.wrapDegrees(angle - heading);
			if (Math.abs(diff) > 80.0F) {
				continue;
			}
			int px = cx + Math.round(diff * pixelsPerDegree);
			boolean cardinal = angle % 45 == 0;
			if (!cardinal) {
				g.fill(px, y + 8, px + 1, y + 12, GRAY);
				continue;
			}
			String label = POINT_NAMES[angle / 45];
			boolean main = angle % 90 == 0;
			g.text(font, label, px - font.width(label) / 2, y + 2, main ? cfg().accentColor() : WHITE, true);
		}
		g.fill(cx, y - 2, cx + 1, y + 1, 0xFFE6C868);
		String degrees = Integer.toString(Mth.floor(Mth.positiveModulo(heading, 360.0F)));
		g.text(font, degrees, cx - font.width(degrees) / 2, y + 15, GRAY, true);
	}

	// ---- Formatting -------------------------------------------------------------------------------------

	private static String formatTime(int ticks) {
		int seconds = ticks / 20;
		return (seconds / 60) + ":" + String.format("%02d", seconds % 60);
	}

	private static String toRoman(int value) {
		return switch (value) {
			case 1 -> "I";
			case 2 -> "II";
			case 3 -> "III";
			case 4 -> "IV";
			case 5 -> "V";
			case 6 -> "VI";
			case 7 -> "VII";
			case 8 -> "VIII";
			case 9 -> "IX";
			case 10 -> "X";
			default -> Integer.toString(value);
		};
	}
}
