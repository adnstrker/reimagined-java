package dev.reimagined.client.entity;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartNames;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

import dev.reimagined.entity.HollowRegentEntity;

/**
 * Hollow Regent model: a 44 unit (2.75 block) tall armoured skeleton king with a spiked crown.
 *
 * <p>Texture sheet is 128x64, laid out by tools/generate_assets.py (head 0,0 / body 0,20 / right arm 48,0 /
 * left arm 72,0 / right leg 48,28 / left leg 76,28 / crown band 0,46 / spikes 104,0 and 112,0).
 * All animation is procedural, driven by the render state (state and attack clocks synced from the server),
 * so poses stay in lock-step with the server-side ability timeline.
 */
public class HollowRegentModel extends EntityModel<HollowRegentRenderState> {
	private final ModelPart head;
	private final ModelPart body;
	private final ModelPart rightArm;
	private final ModelPart leftArm;
	private final ModelPart rightLeg;
	private final ModelPart leftLeg;

	public HollowRegentModel(ModelPart root) {
		super(root);
		this.head = root.getChild(PartNames.HEAD);
		this.body = root.getChild(PartNames.BODY);
		this.rightArm = root.getChild(PartNames.RIGHT_ARM);
		this.leftArm = root.getChild(PartNames.LEFT_ARM);
		this.rightLeg = root.getChild(PartNames.RIGHT_LEG);
		this.leftLeg = root.getChild(PartNames.LEFT_LEG);
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();

		root.addOrReplaceChild(PartNames.BODY,
				CubeListBuilder.create().texOffs(0, 20).addBox(-8.0F, 0.0F, -4.0F, 16.0F, 18.0F, 8.0F),
				PartPose.offset(0.0F, -10.0F, 0.0F));

		PartDefinition headPart = root.addOrReplaceChild(PartNames.HEAD,
				CubeListBuilder.create().texOffs(0, 0).addBox(-5.0F, -10.0F, -5.0F, 10.0F, 10.0F, 10.0F),
				PartPose.offset(0.0F, -10.0F, 0.0F));
		headPart.addOrReplaceChild("crown_band",
				CubeListBuilder.create().texOffs(0, 46).addBox(-5.5F, -11.0F, -5.5F, 11.0F, 2.0F, 11.0F),
				PartPose.ZERO);
		headPart.addOrReplaceChild("crown_spikes",
				CubeListBuilder.create().texOffs(104, 0)
						.addBox(-5.5F, -16.0F, -5.5F, 2.0F, 5.0F, 2.0F)
						.addBox(3.5F, -16.0F, -5.5F, 2.0F, 5.0F, 2.0F)
						.addBox(-5.5F, -16.0F, 3.5F, 2.0F, 5.0F, 2.0F)
						.addBox(3.5F, -16.0F, 3.5F, 2.0F, 5.0F, 2.0F),
				PartPose.ZERO);
		headPart.addOrReplaceChild("crown_front_spike",
				CubeListBuilder.create().texOffs(112, 0).addBox(-1.0F, -18.0F, -5.5F, 2.0F, 7.0F, 2.0F),
				PartPose.ZERO);

		root.addOrReplaceChild(PartNames.RIGHT_ARM,
				CubeListBuilder.create().texOffs(48, 0).addBox(-3.0F, -2.0F, -3.0F, 6.0F, 22.0F, 6.0F),
				PartPose.offset(-11.0F, -8.0F, 0.0F));
		root.addOrReplaceChild(PartNames.LEFT_ARM,
				CubeListBuilder.create().texOffs(72, 0).addBox(-3.0F, -2.0F, -3.0F, 6.0F, 22.0F, 6.0F),
				PartPose.offset(11.0F, -8.0F, 0.0F));
		root.addOrReplaceChild(PartNames.RIGHT_LEG,
				CubeListBuilder.create().texOffs(48, 28).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 16.0F, 7.0F),
				PartPose.offset(-4.5F, 8.0F, 0.0F));
		root.addOrReplaceChild(PartNames.LEFT_LEG,
				CubeListBuilder.create().texOffs(76, 28).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 16.0F, 7.0F),
				PartPose.offset(4.5F, 8.0F, 0.0F));

		return LayerDefinition.create(mesh, 128, 64);
	}

	@Override
	public void setupAnim(HollowRegentRenderState state) {
		super.setupAnim(state);

		float age = state.ageInTicks;
		float swing = state.walkAnimationPos;
		float amplitude = Math.min(1.0F, state.walkAnimationSpeed * 1.6F);

		head.xRot = state.xRot * Mth.DEG_TO_RAD;
		head.yRot = state.yRot * Mth.DEG_TO_RAD;

		// Heavy walk cycle plus a slow breathing sway of the arms.
		rightLeg.xRot = Mth.cos(swing * 0.5F) * 1.0F * amplitude;
		leftLeg.xRot = Mth.cos(swing * 0.5F + Mth.PI) * 1.0F * amplitude;
		rightArm.xRot = Mth.cos(swing * 0.5F + Mth.PI) * 0.5F * amplitude;
		leftArm.xRot = Mth.cos(swing * 0.5F) * 0.5F * amplitude;
		float sway = 0.06F + Mth.cos(age * 0.07F) * 0.03F;
		rightArm.zRot = sway;
		leftArm.zRot = -sway;

		if (state.stateId == HollowRegentEntity.STATE_DORMANT) {
			seated(1.0F);
			return;
		}
		if (state.stateId == HollowRegentEntity.STATE_AWAKENING) {
			float t = clamp01(state.stateAge / HollowRegentEntity.AWAKEN_TICKS);
			seated(1.0F - smooth(t));
			return;
		}

		float t = state.attackAge;
		switch (state.attackId) {
			case HollowRegentEntity.ATTACK_SLAM -> slamPose(t);
			case HollowRegentEntity.ATTACK_BARRAGE -> {
				float p = envelope(t, 24.0F, 40.0F, 8.0F);
				float shake = Mth.sin(t * 2.2F) * 0.04F * p;
				rightArm.xRot = -1.5F * p + shake;
				leftArm.xRot = -1.5F * p - shake;
				rightArm.zRot += 0.22F * p;
				leftArm.zRot -= 0.22F * p;
				head.xRot += 0.1F * p;
			}
			case HollowRegentEntity.ATTACK_SUMMON -> {
				float p = envelope(t, 30.0F, 46.0F, 10.0F);
				rightArm.zRot = 1.5F * p;
				leftArm.zRot = -1.5F * p;
				rightArm.xRot = -0.4F * p;
				leftArm.xRot = -0.4F * p;
				head.xRot -= 0.5F * p;
			}
			case HollowRegentEntity.ATTACK_ROAR -> {
				float p = envelope(t, 14.0F, 44.0F, 12.0F);
				rightArm.zRot = 1.1F * p;
				leftArm.zRot = -1.1F * p;
				rightArm.xRot = -0.25F * p;
				leftArm.xRot = -0.25F * p;
				head.xRot -= 0.7F * p;
			}
			default -> {
			}
		}
	}

	/** Raise both arms over the head, smash down at the impact tick, then recover. */
	private void slamPose(float t) {
		float arm;
		if (t < HollowRegentEntity.SLAM_IMPACT) {
			arm = -3.0F * smooth(clamp01(t / HollowRegentEntity.SLAM_IMPACT));
			head.xRot -= 0.3F * smooth(clamp01(t / HollowRegentEntity.SLAM_IMPACT));
		} else if (t < HollowRegentEntity.SLAM_IMPACT + 6.0F) {
			float q = (t - HollowRegentEntity.SLAM_IMPACT) / 6.0F;
			arm = Mth.lerp(q, -3.0F, -0.3F);
			head.xRot += 0.4F * q;
		} else {
			float r = clamp01((t - HollowRegentEntity.SLAM_IMPACT - 6.0F) / 10.0F);
			arm = Mth.lerp(r, -0.3F, 0.0F);
			head.xRot += 0.4F * (1.0F - r);
		}
		rightArm.xRot = arm;
		leftArm.xRot = arm;
		rightArm.zRot += 0.2F;
		leftArm.zRot -= 0.2F;
	}

	/**
	 * Sitting on the throne: knees forward, hips dropped, head bowed, hands resting on the thighs.
	 * {@code amount} blends from standing (0) to fully seated (1).
	 */
	private void seated(float amount) {
		float drop = 9.0F * amount;
		head.y += drop;
		body.y += drop;
		rightArm.y += drop;
		leftArm.y += drop;
		rightLeg.y += drop;
		leftLeg.y += drop;
		rightLeg.xRot = Mth.lerp(amount, rightLeg.xRot, -1.45F);
		leftLeg.xRot = Mth.lerp(amount, leftLeg.xRot, -1.45F);
		rightArm.xRot = Mth.lerp(amount, rightArm.xRot, -0.55F);
		leftArm.xRot = Mth.lerp(amount, leftArm.xRot, -0.55F);
		head.xRot = Mth.lerp(amount, head.xRot, 0.65F);
		head.yRot = Mth.lerp(amount, head.yRot, 0.0F);
	}

	/** 0 to 1 over {@code rise} ticks, held until {@code holdUntil}, then back to 0 over {@code fall} ticks. */
	private static float envelope(float t, float rise, float holdUntil, float fall) {
		if (t < holdUntil) {
			return smooth(clamp01(t / rise));
		}
		return smooth(clamp01(1.0F - (t - holdUntil) / fall));
	}

	private static float clamp01(float v) {
		return Mth.clamp(v, 0.0F, 1.0F);
	}

	private static float smooth(float p) {
		return p * p * (3.0F - 2.0F * p);
	}
}
