package dev.reimagined.client.hud;

import java.util.LinkedHashMap;
import java.util.Map;

import net.minecraft.client.Minecraft;

import dev.reimagined.network.BossBarPayload;

/** Client-side store of the latest boss status packets. Entries expire if the server stops updating them. */
public final class BossBarTracker {
	public record Entry(float health, float maxHealth, int phase, int state, long receivedAt) {
	}

	private static final Map<Integer, Entry> ENTRIES = new LinkedHashMap<>();

	public static void update(BossBarPayload payload) {
		Minecraft minecraft = Minecraft.getInstance();
		long now = minecraft.level != null ? minecraft.level.getGameTime() : 0L;
		ENTRIES.put(payload.entityId(), new Entry(payload.health(), payload.maxHealth(), payload.phase(), payload.state(), now));
	}

	public static Map<Integer, Entry> entries() {
		return ENTRIES;
	}

	/** Drops stale entries; returns the map for convenience. */
	public static Map<Integer, Entry> prune(long now) {
		ENTRIES.values().removeIf(e -> now - e.receivedAt() > 30L);
		return ENTRIES;
	}

	private BossBarTracker() {
	}
}
