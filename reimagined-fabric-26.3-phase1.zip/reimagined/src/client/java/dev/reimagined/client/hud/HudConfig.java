package dev.reimagined.client.hud;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import net.fabricmc.loader.api.FabricLoader;

import dev.reimagined.ReimaginedMod;

/** Client-only HUD options, stored in {@code config/reimagined_hud.json}. Edited through the in-game settings screen (default key: H). */
public final class HudConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static HudConfig instance = new HudConfig();

	/** Replaces the vanilla health, hunger, armor and level indicators. */
	public boolean statusBars = true;
	/** Draws the styled boss bar (with phase markers) for Reimagined bosses. */
	public boolean bossBar = true;
	/** Attack cooldown and weapon durability under the crosshair. */
	public boolean weaponInfo = true;
	/** Replaces the vanilla effect icons with icons plus names and timers. */
	public boolean effectTimers = true;
	public boolean coordinates = false;
	public boolean biome = false;
	public boolean compass = false;
	/** Info panel corner: 0 top-left, 1 top-right, 2 bottom-left, 3 bottom-right. */
	public int corner = 0;
	/** Accent colour preset: 0 soul cyan, 1 royal gold, 2 crimson, 3 violet. */
	public int accent = 0;

	public static HudConfig get() {
		return instance;
	}

	public int accentColor() {
		return switch (accent) {
			case 1 -> 0xFFE6C868;
			case 2 -> 0xFFE0524A;
			case 3 -> 0xFFA67CFF;
			default -> 0xFF4FE0D0;
		};
	}

	/** A darker shade of the accent, used for frames. */
	public int accentDark() {
		return switch (accent) {
			case 1 -> 0xFF8A6A2A;
			case 2 -> 0xFF7A2A28;
			case 3 -> 0xFF54408A;
			default -> 0xFF2A7A72;
		};
	}

	public static void load() {
		Path file = path();
		try {
			if (Files.exists(file)) {
				HudConfig loaded = GSON.fromJson(Files.readString(file), HudConfig.class);
				if (loaded != null) {
					instance = loaded;
				}
			}
		} catch (IOException | RuntimeException e) {
			ReimaginedMod.LOGGER.error("Could not read reimagined_hud.json, using defaults", e);
		}
	}

	public static void save() {
		try {
			Files.writeString(path(), GSON.toJson(instance));
		} catch (IOException e) {
			ReimaginedMod.LOGGER.error("Could not write reimagined_hud.json", e);
		}
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("reimagined_hud.json");
	}

	private HudConfig() {
	}
}
