package dev.reimagined.client;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRenderers;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import dev.reimagined.client.entity.HollowRegentRenderer;
import dev.reimagined.client.entity.ModModelLayers;
import dev.reimagined.client.hud.BossBarTracker;
import dev.reimagined.client.hud.HudConfig;
import dev.reimagined.client.hud.HudSettingsScreen;
import dev.reimagined.client.hud.ReimaginedHud;
import dev.reimagined.entity.ModEntities;
import dev.reimagined.network.BossBarPayload;

public class ReimaginedClient implements ClientModInitializer {
	private KeyMapping hudSettingsKey;

	@Override
	public void onInitializeClient() {
		ModModelLayers.registerModelLayers();
		EntityRenderers.register(ModEntities.HOLLOW_REGENT, HollowRegentRenderer::new);

		HudConfig.load();
		ReimaginedHud.register();
		ClientPlayNetworking.registerGlobalReceiver(BossBarPayload.TYPE, (payload, context) -> BossBarTracker.update(payload));

		hudSettingsKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.reimagined.hud_settings",
				InputConstants.Type.KEYSYM,
				InputConstants.KEY_H,
				KeyMapping.Category.MISC
		));
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (hudSettingsKey.consumeClick()) {
				Minecraft minecraft = Minecraft.getInstance();
				if (minecraft.screen == null) {
					minecraft.gui.setScreen(new HudSettingsScreen(null));
				}
			}
		});
	}
}
